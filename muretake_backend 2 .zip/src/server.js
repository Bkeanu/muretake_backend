const express = require('express');
const helmet = require('helmet');
const cors = require('cors');

require('dotenv').config();

const pool = require('./db');
const authRoutes = require('./routes/auth.routes');
const adminRoutes = require('./routes/admin.routes');
const contractRoutes = require('./routes/contracts.routes');
const reportRoutes = require('./routes/reports.routes');

const {
  generalApiLimiter,
} = require('./middleware/rateLimit.middleware');

const app = express();

app.disable('x-powered-by');

const PORT = process.env.PORT || 3000;

// ================================
// SECURITY MIDDLEWARE
// ================================

app.use(helmet());

// Keep this permissive for now.
// We will restrict CORS later during production hardening.
app.use(cors());

app.use(
  express.json({
    limit: '100kb',
  }),
);

app.use(
  express.urlencoded({
    extended: false,
    limit: '100kb',
  }),
);

// ================================
// GENERAL API RATE LIMIT
// ================================

app.use('/api', generalApiLimiter);

// ================================
// API ROUTES
// ================================

// Authentication
app.use('/api/auth', authRoutes);

// Admin
app.use('/api/admin', adminRoutes);

// Contracts
app.use('/api/contracts', contractRoutes);

// Reports
app.use('/api/reports', reportRoutes);

// ================================
// BASIC HEALTH CHECK
// ================================

app.get('/api/health', (req, res) => {
  return res.status(200).json({
    status: 'ok',
    message: 'Muretake API is running',
  });
});

// ================================
// DATABASE HEALTH CHECK
// ================================

app.get('/api/db-health', async (req, res, next) => {
  try {
    const result = await pool.query(
      'SELECT NOW() AS database_time',
    );

    return res.status(200).json({
      status: 'ok',
      message: 'Neon PostgreSQL connected',
      databaseTime: result.rows[0].database_time,
    });
  } catch (error) {
    return next(error);
  }
});

// ================================
// 404 HANDLER
// ================================

app.use((req, res) => {
  return res.status(404).json({
    error: 'NOT_FOUND',
    message: 'API endpoint haijapatikana.',
  });
});

// ================================
// GLOBAL ERROR HANDLER
// ================================

app.use((err, req, res, next) => {
  // Detailed error stays on the server only.
  console.error('Unhandled server error:', err);

  const networkErrorCodes = new Set([
    'ETIMEDOUT',
    'ECONNREFUSED',
    'ECONNRESET',
    'ENETUNREACH',
    'EHOSTUNREACH',
  ]);

  const directNetworkError =
    networkErrorCodes.has(err?.code);

  const aggregateNetworkError =
    err instanceof AggregateError &&
    Array.isArray(err.errors) &&
    err.errors.some((error) =>
      networkErrorCodes.has(error?.code),
    );

  if (directNetworkError || aggregateNetworkError) {
    return res.status(503).json({
      error: 'SERVICE_UNAVAILABLE',
      message:
        'Huduma haipatikani kwa muda. Tafadhali jaribu tena.',
    });
  }

  return res.status(500).json({
    error: 'INTERNAL_SERVER_ERROR',
    message: 'Hitilafu imetokea kwenye seva.',
  });
});

// ================================
// START SERVER
// ================================

app.listen(PORT, '0.0.0.0', () => {
  console.log(
    `Muretake API running on http://localhost:${PORT}`,
  );
});
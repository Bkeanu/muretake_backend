const jwt = require('jsonwebtoken');
const pool = require('../db');

async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required.',
    });
  }

  const token = authHeader.slice(7).trim();

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Authentication required.',
    });
  }

  try {
    const payload = jwt.verify(
      token,
      process.env.JWT_ACCESS_SECRET,
      {
        issuer: 'muretake-api',
        audience: 'muretake-app',
      },
    );

    // Verify that the account still exists and is active.
    // This is parameterized SQL: the user id is passed separately as $1.
    const result = await pool.query(
      `
      SELECT
        id,
        role,
        branch_id,
        is_active,
        password_changed_at
      FROM users
      WHERE id = $1
      LIMIT 1
      `,
      [payload.sub],
    );

    if (result.rows.length === 0 || !result.rows[0].is_active) {
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication session.',
      });
    }

    const user = result.rows[0];

    // If the password was changed after this access token was issued,
    // reject the old token. This makes password changes invalidate old logins.
    if (user.password_changed_at && payload.iat) {
      const tokenIssuedAtSeconds = Number(payload.iat);
      const passwordChangedAtSeconds = Math.floor(
        new Date(user.password_changed_at).getTime() / 1000,
      );

      if (passwordChangedAtSeconds > tokenIssuedAtSeconds) {
        return res.status(401).json({
          success: false,
          message: 'Session expired after password change. Please log in again.',
        });
      }
    }

    req.user = {
      id: user.id,
      role: user.role,
      branchId: user.branch_id,
    };

    return next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired access token.',
    });
  }
}

module.exports = {
  requireAuth,
};

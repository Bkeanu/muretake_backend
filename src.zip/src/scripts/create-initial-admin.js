const readline = require('readline/promises');
const { stdin: input, stdout: output } = require('process');

require('dotenv').config();

const pool = require('../db');
const { hashPassword } = require('../services/password.service');

async function createInitialAdmin() {
  const rl = readline.createInterface({
    input,
    output,
  });

  try {
    console.log('\n=== Muretake Initial Admin Setup ===\n');

    const fullName = (await rl.question('Admin full name: ')).trim();
    const username = (await rl.question('Admin username: ')).trim();
    const password = (await rl.question('Temporary admin password: ')).trim();

    if (!fullName || !username || !password) {
      console.log('All fields are required.');
      return;
    }

    if (username.length < 3) {
      console.log('Username must contain at least 3 characters.');
      return;
    }

    if (password.length < 10) {
      console.log('Password must contain at least 10 characters.');
      return;
    }

    // Check whether an admin already exists.
    // $1 is a parameterized value — no SQL string concatenation.
    const existingAdmin = await pool.query(
      `
      SELECT id
      FROM users
      WHERE role = $1
      LIMIT 1
      `,
      ['admin'],
    );

    if (existingAdmin.rows.length > 0) {
      console.log('An admin account already exists.');
      return;
    }

    // Check whether username already exists.
    const existingUsername = await pool.query(
      `
      SELECT id
      FROM users
      WHERE LOWER(username) = LOWER($1)
      LIMIT 1
      `,
      [username],
    );

    if (existingUsername.rows.length > 0) {
      console.log('That username is already being used.');
      return;
    }

    // Hash plaintext password using Argon2id.
    const passwordHash = await hashPassword(password);

    // Only the HASH goes into PostgreSQL.
    const result = await pool.query(
      `
      INSERT INTO users (
        full_name,
        username,
        password_hash,
        role,
        branch_id,
        is_active,
        must_change_password,
        failed_attempts
      )
      VALUES (
        $1,
        $2,
        $3,
        $4,
        NULL,
        TRUE,
        TRUE,
        0
      )
      RETURNING
        id,
        full_name,
        username,
        role,
        is_active,
        must_change_password,
        created_at
      `,
      [
        fullName,
        username,
        passwordHash,
        'admin',
      ],
    );

    console.log('\nAdmin created successfully.\n');

    console.table(result.rows);
  } catch (error) {
    console.error('Failed to create admin:');
    console.error(error);
  }finally {
    rl.close();
    await pool.end();
  }
}

createInitialAdmin();
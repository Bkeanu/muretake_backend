const express = require('express');

const {
  sensitiveActionLimiter,
} = require('../middleware/rateLimit.middleware');



const {
  createContract,
  listMyContracts,
  listBranchContracts,
  getPaymentByRequestId,
  getPenaltySettlementByRequestId,
  listMissedReturnsByDate,
  listReturnsByDate,
  listPenalties,
  settlePenalty,
  recordPayment,
} = require('../controllers/contracts.controller');

const {
  requireAuth,
} = require('../middleware/auth.middleware');

const router = express.Router();

// GET /api/contracts/branch
// Returns operational contracts for the authenticated officer's assigned branch.
router.get('/branch', requireAuth, listBranchContracts);


// GET /api/contracts/penalties
// Generates any missed historical scheduled-payment penalties through yesterday
// for the authenticated officer's branch, then returns all open penalties.
router.get('/penalties', requireAuth, listPenalties);

router.get(
  '/penalties/settlements/by-request/:requestId',
  requireAuth,
  getPenaltySettlementByRequestId,
);

// POST /api/contracts/:contractId/penalties/settle
// Any active officer in the same branch may settle all currently-open
// penalties for the contract. If amount is below the accrued penalty, the
// difference is recorded as waived/discounted and the penalty is closed.
router.post(
  '/:contractId/penalties/settle',
  requireAuth,
  sensitiveActionLimiter,
  settlePenalty,
);

// GET /api/contracts/returns?date=YYYY-MM-DD
// Returns actual Rejesho transactions for the authenticated officer's branch.
router.get('/returns', requireAuth, listReturnsByDate);

// GET /api/contracts/missed-returns?date=YYYY-MM-DD
// Returns borrowers in the authenticated officer's branch who had a
// scheduled Rejesho on that date but no payment was recorded that day.
router.get('/missed-returns', requireAuth, listMissedReturnsByDate);

// GET /api/contracts/mine
// Kept for compatibility with older app builds.
router.get('/mine', requireAuth, listMyContracts);

router.get(
  '/payments/by-request/:requestId',
  requireAuth,
  getPaymentByRequestId,
);
// POST /api/contracts/:contractId/payments
// Any active officer may record a Rejesho for a contract in their own branch.
router.post('/:contractId/payments', requireAuth,  sensitiveActionLimiter,
  recordPayment);

// POST /api/contracts
router.post('/', requireAuth, sensitiveActionLimiter, createContract);

module.exports = router;

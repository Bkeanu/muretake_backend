const fs = require('node:fs');
const path = require('node:path');
const pool = require('../db');

async function main() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const sql = fs.readFileSync(path.join(__dirname, '../../migrations/001_daily_reports.sql'), 'utf8');
    await client.query(sql);
    await client.query('COMMIT');
    console.log('Daily Reports table created successfully.');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Setup failed; changes rolled back:', error.message);
    console.error('If daily_reports already exists, do not delete it. Share this error for inspection.');
    process.exitCode = 1;
  } finally {
    client.release();
  }
}
main().catch((error) => {
  console.error('Database connection failed:', error.code || error.name);
  process.exitCode = 1;
}).finally(() => pool.end());

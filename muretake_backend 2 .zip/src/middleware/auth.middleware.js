const jwt = require('jsonwebtoken');
const pool = require('../db');

async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      code: 'AUTH_REQUIRED',
      message: 'Authentication required.',
    });
  }

  const token = authHeader.slice(7).trim();

  if (!token) {
    return res.status(401).json({
      success: false,
      code: 'AUTH_REQUIRED',
      message: 'Authentication required.',
    });
  }

  try {
    const payload = jwt.verify(
      token,
      process.env.JWT_ACCESS_SECRET,
      {
        issuer: 'muretake-api',
        audience: 'muretake-app',
      },
    );

    if (!payload.sub || !payload.sid) {
      return res.status(401).json({
        success: false,
        code: 'INVALID_SESSION',
        message: 'Invalid authentication session.',
      });
    }

    const result = await pool.query(
      `
      UPDATE auth_sessions AS s
      SET last_used_at = NOW()
      FROM users AS u
      WHERE s.user_id = u.id
        AND u.id = $1
        AND s.session_id = $2
        AND s.revoked_at IS NULL
        AND s.expires_at > NOW()
        AND s.absolute_expires_at > NOW()
        AND u.is_active = TRUE
        AND s.last_used_at > NOW() - CASE
          WHEN u.role = 'admin' THEN INTERVAL '10 minutes'
          ELSE INTERVAL '20 minutes'
        END
      RETURNING
        u.id,
        u.role,
        u.branch_id,
        u.password_changed_at,
        s.session_id,
        s.absolute_expires_at
      `,
      [payload.sub, payload.sid],
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        code: 'SESSION_EXPIRED',
        message: 'Kikao chako kimeisha. Tafadhali ingia tena.',
      });
    }

    const user = result.rows[0];

    if (user.password_changed_at && payload.iat) {
      const tokenIssuedAtSeconds = Number(payload.iat);
      const passwordChangedAtSeconds = Math.floor(
        new Date(user.password_changed_at).getTime() / 1000,
      );

      if (passwordChangedAtSeconds > tokenIssuedAtSeconds) {
        await pool.query(
          `
          UPDATE auth_sessions
          SET revoked_at = NOW()
          WHERE user_id = $1 AND session_id = $2
          `,
          [user.id, user.session_id],
        );

        return res.status(401).json({
          success: false,
          code: 'SESSION_EXPIRED',
          message: 'Kikao kimeisha baada ya kubadilisha nenosiri. Tafadhali ingia tena.',
        });
      }
    }

    req.user = {
      id: user.id,
      role: user.role,
      branchId: user.branch_id,
      sessionId: user.session_id,
    };

    return next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      code: 'INVALID_OR_EXPIRED_TOKEN',
      message: 'Kikao chako kimeisha. Tafadhali ingia tena.',
    });
  }
}

module.exports = {
  requireAuth,
};

const rateLimit = require('express-rate-limit');

const generalApiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 600,
  standardHeaders: true,
  legacyHeaders: false,
});

const loginLimiter = rateLimit({
  windowMs: 30 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,

  message: {
    success: false,
    message:
      'Umejaribu kuingia mara nyingi. Tafadhali subiri  kisha ujaribu tena.',
  },
});

const sensitiveActionLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false,
});

module.exports = {
  generalApiLimiter,
  loginLimiter,
  sensitiveActionLimiter,
};
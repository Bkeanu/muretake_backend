const pool = require('../db');

const TZ = 'Africa/Dar_es_Salaam';

function parseDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return null;
  }
  return value;
}

function nonNegativeMoney(value) {
  if (value === null || value === undefined || value === '') return 0;

  const number = Number(value);

  if (
    !Number.isFinite(number) ||
    !Number.isInteger(number) ||
    number < 0 ||
    number > 10000000
  ) {
    return null;
  }

  return number;
}

function mapReport(row) {
  if (!row) return null;
  return {
    id: row.id,
    date: row.report_date,
    branchName: row.branch_name,
    officerName: row.officer_name,
    currentBalance: Number(row.current_balance),
    dailyCollections: Number(row.daily_collections),
    penalties: Number(row.penalties),
    deductions: Number(row.deductions),
    allFormsPrincipal: Number(row.all_forms_principal),
    newContracts: Number(row.new_contracts),
    activeContracts: Number(row.active_contracts),
    completedContracts: Number(row.completed_contracts),
    overdueContracts: Number(row.overdue_contracts),
    store: Number(row.store),
    allowance: Number(row.allowance),
    stationery: Number(row.stationery),
    rent: Number(row.rent),
    otherExpenses: Number(row.other_expenses),
    totalExpenses: Number(row.total_expenses),
    netBalance: Number(row.net_balance),
    cash: row.cash_balance == null ? null : Number(row.cash_balance),
    phoneMoney: row.phone_balance == null ? null : Number(row.phone_balance),
    notes: row.notes || '',
    submittedAt: row.submitted_at,
  };
}

async function getSummaryForBranch(client, branchId, officerId, date) {
  const result = await client.query(
    `
    SELECT
      b.name AS branch_name,
      u.full_name AS officer_name,
      b.current_balance,

      COALESCE((
        SELECT SUM(p.amount)
        FROM payments p
        WHERE p.branch_id = b.id
          AND (p.paid_at AT TIME ZONE $3)::date = $4::date
      ), 0) AS daily_collections,

      COALESCE((
        SELECT SUM(ps.amount_paid)
        FROM penalty_settlements ps
        WHERE ps.branch_id = b.id
          AND (ps.settled_at AT TIME ZONE $3)::date = $4::date
      ), 0) AS penalties,

      0::numeric AS deductions,

      COALESCE((
        SELECT SUM(c.borrowed_amount)
        FROM contracts c
        WHERE c.branch_id = b.id
          AND c.approved_at IS NOT NULL
          AND (c.approved_at AT TIME ZONE $3)::date = $4::date
      ), 0) AS all_forms_principal,

      COALESCE((
        SELECT COUNT(*)
        FROM contracts c
        WHERE c.branch_id = b.id
          AND c.approved_at IS NOT NULL
          AND (c.approved_at AT TIME ZONE $3)::date = $4::date
      ), 0)::int AS new_contracts,

      COALESCE((
        SELECT COUNT(*) FROM contracts c
        WHERE c.branch_id = b.id AND c.status = 'active'
      ), 0)::int AS active_contracts,

      COALESCE((
        SELECT COUNT(*) FROM contracts c
        WHERE c.branch_id = b.id AND c.status = 'completed'
      ), 0)::int AS completed_contracts,

      COALESCE((
        SELECT COUNT(*) FROM contracts c
        WHERE c.branch_id = b.id AND c.status = 'defaulted'
      ), 0)::int AS overdue_contracts,

      EXISTS (
        SELECT 1 FROM daily_reports dr
        WHERE dr.branch_id = b.id AND dr.report_date = $4::date
      ) AS already_submitted

    FROM branches b
    JOIN users u ON u.id = $2
    WHERE b.id = $1
      AND b.is_active = TRUE
    LIMIT 1
    `,
    [branchId, officerId, TZ, date],
  );

  if (result.rows.length === 0) return null;
  const row = result.rows[0];

  return {
    date,
    branchName: row.branch_name,
    officerName: row.officer_name,
    currentBalance: Number(row.current_balance),
    dailyCollections: Number(row.daily_collections),
    penalties: Number(row.penalties),
    // No trusted Makato ledger exists yet, so it is deliberately zero.
    deductions: Number(row.deductions),
    allFormsPrincipal: Number(row.all_forms_principal),
    newContracts: Number(row.new_contracts),
    activeContracts: Number(row.active_contracts),
    completedContracts: Number(row.completed_contracts),
    overdueContracts: Number(row.overdue_contracts),
    // No trusted cash/mobile-money ledger exists yet.
    cash: null,
    phoneMoney: null,
    alreadySubmitted: row.already_submitted === true,
  };
}

async function getDailyReportSummary(req, res) {
  if (req.user.role !== 'officer' || !req.user.branchId) {
    return res.status(403).json({
      success: false,
      message: 'Ripoti ya tawi inapatikana kwa Mweka Hazina tu.',
    });
  }

  const date = parseDate(req.query.date);
  if (!date) {
    return res.status(400).json({ success: false, message: 'Tarehe si sahihi.' });
  }

  try {
    const summary = await getSummaryForBranch(pool, req.user.branchId, req.user.id, date);
    if (!summary) {
      return res.status(404).json({ success: false, message: 'Tawi halijapatikana.' });
    }
    return res.json({ success: true, summary });
  } catch (error) {
    console.error('getDailyReportSummary error:', error);
    return res.status(500).json({ success: false, message: 'Imeshindikana kuandaa ripoti.' });
  }
}

async function submitDailyReport(req, res) {
  if (req.user.role !== 'officer' || !req.user.branchId) {
    return res.status(403).json({ success: false, message: 'Huna ruhusa ya kutuma ripoti hii.' });
  }

  const date = parseDate(req.body?.date);
  if (!date) {
    return res.status(400).json({ success: false, message: 'Tarehe si sahihi.' });
  }

  const expenses = req.body?.expenses || {};
  const store = nonNegativeMoney(expenses.store);
  const allowance = nonNegativeMoney(expenses.allowance);
  const stationery = nonNegativeMoney(expenses.stationery);
  const rent = nonNegativeMoney(expenses.rent);
  const otherExpenses = nonNegativeMoney(expenses.otherExpenses);

  if ([store, allowance, stationery, rent, otherExpenses].some((v) => v === null)) {
    return res.status(400).json({
      success: false,
      message: 'Matumizi lazima yawe TSH kamili kati ya TSH 0 na TSH 10,000,000.',
    });
  }

  const notes = typeof req.body?.notes === 'string' ? req.body.notes.trim() : '';
  if (notes.length > 1000) {
    return res.status(400).json({ success: false, message: 'Maelezo ni marefu sana.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const todayResult = await client.query(
      `SELECT (NOW() AT TIME ZONE $1)::date::text AS today`,
      [TZ],
    );
    if (todayResult.rows[0].today !== date) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        success: false,
        message: 'Ripoti inaweza kuwasilishwa kwa tarehe ya leo tu.',
      });
    }

    const summary = await getSummaryForBranch(
      client,
      req.user.branchId,
      req.user.id,
      date,
    );
    if (!summary) {
      await client.query('ROLLBACK');
      return res.status(404).json({ success: false, message: 'Tawi halijapatikana.' });
    }
    if (summary.alreadySubmitted) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Ripoti ya tawi hili kwa leo tayari imewasilishwa.',
      });
    }

    const totalExpenses = store + allowance + stationery + rent + otherExpenses;
    const netBalance =
      summary.currentBalance +
      summary.dailyCollections +
      summary.penalties +
      summary.deductions -
      totalExpenses;

    const insert = await client.query(
      `
      INSERT INTO daily_reports (
        report_date, branch_id, officer_id,
        current_balance, daily_collections, penalties, deductions,
        all_forms_principal,
        new_contracts, active_contracts, completed_contracts, overdue_contracts,
        store, allowance, stationery, rent, other_expenses,
        total_expenses, net_balance,
        cash_balance, phone_balance,
        notes
      ) VALUES (
        $1, $2, $3,
        $4, $5, $6, $7,
        $8,
        $9, $10, $11, $12,
        $13, $14, $15, $16, $17,
        $18, $19,
        NULL, NULL,
        NULLIF($20, '')
      )
      RETURNING *
      `,
      [
        date,
        req.user.branchId,
        req.user.id,
        summary.currentBalance,
        summary.dailyCollections,
        summary.penalties,
        summary.deductions,
        summary.allFormsPrincipal,
        summary.newContracts,
        summary.activeContracts,
        summary.completedContracts,
        summary.overdueContracts,
        store,
        allowance,
        stationery,
        rent,
        otherExpenses,
        totalExpenses,
        netBalance,
        notes,
      ],
    );

    await client.query('COMMIT');

    const row = insert.rows[0];
    return res.status(201).json({
      success: true,
      report: {
        id: row.id,
        date: row.report_date,
        netBalance: Number(row.net_balance),
        totalExpenses: Number(row.total_expenses),
        submittedAt: row.submitted_at,
      },
    });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'Ripoti ya tawi hili kwa tarehe hii tayari imewasilishwa.',
      });
    }
    console.error('submitDailyReport error:', error);
    return res.status(500).json({ success: false, message: 'Imeshindikana kuhifadhi ripoti.' });
  } finally {
    client.release();
  }
}

async function listDailyReports(req, res) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin pekee anaweza kuona ripoti zote.' });
  }

  const date = parseDate(req.query.date);
  if (!date) {
    return res.status(400).json({ success: false, message: 'Tarehe si sahihi.' });
  }

  try {
    const result = await pool.query(
      `
      SELECT
        b.id AS branch_id,
        b.name AS branch_name,
        dr.*,
        u.full_name AS officer_name
      FROM branches b
      LEFT JOIN daily_reports dr
        ON dr.branch_id = b.id
       AND dr.report_date = $1::date
      LEFT JOIN users u ON u.id = dr.officer_id
      WHERE b.is_active = TRUE
      ORDER BY b.name
      `,
      [date],
    );

    const branches = result.rows.map((row) => ({
      branchId: row.branch_id,
      branchName: row.branch_name,
      report: row.id ? mapReport(row) : null,
    }));

    return res.json({ success: true, branches });
  } catch (error) {
    console.error('listDailyReports error:', error);
    return res.status(500).json({ success: false, message: 'Imeshindikana kupata ripoti.' });
  }
}

module.exports = {
  getDailyReportSummary,
  submitDailyReport,
  listDailyReports,
};

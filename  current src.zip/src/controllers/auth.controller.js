const pool = require('../db');

const {
  hashPassword,
  verifyPassword,
} = require('../services/password.service');

const {
  createAccessToken,
  createRefreshToken,
  hashRefreshToken,
} = require('../services/token.service');


async function login(req, res) {
  const username =
      typeof req.body.username === 'string'
          ? req.body.username.trim()
          : '';

  const password =
      typeof req.body.password === 'string'
          ? req.body.password
          : '';

  const loginType =
      typeof req.body.loginType === 'string'
          ? req.body.loginType.trim().toLowerCase()
          : '';

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: 'Username and password are required.',
    });
  }

  if (loginType && !['admin', 'officer'].includes(loginType)) {
    return res.status(400).json({
      success: false,
      message: 'Invalid login type.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // PARAMETERIZED QUERY.
    // User input is never concatenated into SQL.
    const result = await client.query(
      `
      SELECT
        u.id,
        u.full_name,
        u.username,
        u.password_hash,
        u.role,
        u.branch_id,
        b.name AS branch_name,
        u.is_active,
        u.must_change_password,
        u.failed_attempts,
        u.locked_until
      FROM users AS u
      LEFT JOIN branches AS b
        ON b.id = u.branch_id
      WHERE LOWER(u.username) = LOWER($1)
      LIMIT 1
      FOR UPDATE OF u
      `,
      [username],
    );

    // Generic response so we don't reveal whether
    // a username exists.
    if (result.rows.length === 0) {
      await client.query('COMMIT');

      return res.status(401).json({
        success: false,
        message: 'Username or password is incorrect.',
      });
    }

    const user = result.rows[0];

    if (!user.is_active) {
      await client.query('COMMIT');

      return res.status(403).json({
        success: false,
        message: 'This account is disabled.',
      });
    }

    const now = new Date();

    // Check existing lockout.
    if (
      user.locked_until &&
      new Date(user.locked_until) > now
    ) {
      await client.query('COMMIT');

      return res.status(423).json({
        success: false,
        message: 'Account is temporarily locked.',
        lockedUntil: user.locked_until,
      });
    }

    // If an old lock has already expired, clear it.
    if (
      user.locked_until &&
      new Date(user.locked_until) <= now
    ) {
      await client.query(
        `
        UPDATE users
        SET
          failed_attempts = 0,
          locked_until = NULL,
          updated_at = NOW()
        WHERE id = $1
        `,
        [user.id],
      );

      user.failed_attempts = 0;
      user.locked_until = null;
    }

    // Argon2id verification.
    const passwordCorrect = await verifyPassword(
      user.password_hash,
      password,
    );

    if (!passwordCorrect) {
      const newFailedAttempts =
          Number(user.failed_attempts || 0) + 1;

      // 3 incorrect attempts triggers lockout.
      if (newFailedAttempts >= 3) {
        const lockHours =
            user.role === 'admin' ? 5 : 3;

        const lockedUntil =
            new Date(
              Date.now() +
              lockHours * 60 * 60 * 1000,
            );

        await client.query(
          `
          UPDATE users
          SET
            failed_attempts = 0,
            locked_until = $1,
            updated_at = NOW()
          WHERE id = $2
          `,
          [
            lockedUntil,
            user.id,
          ],
        );

        await client.query('COMMIT');

        return res.status(423).json({
          success: false,
          message:
              'Too many failed login attempts. Account locked temporarily.',
          lockedUntil,
        });
      }

      await client.query(
        `
        UPDATE users
        SET
          failed_attempts = $1,
          updated_at = NOW()
        WHERE id = $2
        `,
        [
          newFailedAttempts,
          user.id,
        ],
      );

      await client.query('COMMIT');

      return res.status(401).json({
        success: false,
        message: 'Username or password is incorrect.',
        remainingAttempts:
            3 - newFailedAttempts,
      });
    }

    // If the UI supplied a login type, make sure the authenticated
    // account actually belongs to that role before issuing tokens.
    if (loginType && user.role !== loginType) {
      await client.query('COMMIT');

      return res.status(403).json({
        success: false,
        message: 'This account does not match the selected login type.',
      });
    }

    // Password was correct.
    // Reset failed-login information.
    await client.query(
      `
      UPDATE users
      SET
        failed_attempts = 0,
        locked_until = NULL,
        updated_at = NOW()
      WHERE id = $1
      `,
      [user.id],
    );

    const accessToken =
        createAccessToken(user);

    const refreshToken =
        createRefreshToken();

    const refreshTokenHash =
        hashRefreshToken(refreshToken);

    const refreshDays =
        Number(
          process.env.REFRESH_TOKEN_DAYS || 7,
        );

    const refreshExpiresAt =
        new Date(
          Date.now() +
          refreshDays *
          24 *
          60 *
          60 *
          1000,
        );

    // Only the HASH of the refresh token
    // is stored in PostgreSQL.
    await client.query(
      `
      INSERT INTO auth_sessions (
        user_id,
        refresh_token_hash,
        expires_at
      )
      VALUES (
        $1,
        $2,
        $3
      )
      `,
      [
        user.id,
        refreshTokenHash,
        refreshExpiresAt,
      ],
    );

    await client.query('COMMIT');

    return res.status(200).json({
      success: true,

      user: {
        id: user.id,
        fullName: user.full_name,
        username: user.username,
        role: user.role,
        branchId: user.branch_id,
        branchName: user.branch_name,
        mustChangePassword:
            user.must_change_password,
      },

      accessToken,
      refreshToken,
    });

  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Login error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });

  } finally {
    client.release();
  }
}


async function changePassword(req, res) {
  const userId = req.user.id;

  const currentPassword =
      typeof req.body.currentPassword === 'string'
          ? req.body.currentPassword
          : '';

  const newPassword =
      typeof req.body.newPassword === 'string'
          ? req.body.newPassword
          : '';

  if (!currentPassword || !newPassword) {
    return res.status(400).json({
      success: false,
      message: 'Current password and new password are required.',
    });
  }

  if (newPassword.length < 10) {
    return res.status(400).json({
      success: false,
      message: 'New password must contain at least 10 characters.',
    });
  }

  if (newPassword.length > 128) {
    return res.status(400).json({
      success: false,
      message: 'New password is too long.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // Parameterized SQL: userId is data, never concatenated into SQL.
    const result = await client.query(
      `
      SELECT
        id,
        password_hash,
        is_active
      FROM users
      WHERE id = $1
      LIMIT 1
      FOR UPDATE
      `,
      [userId],
    );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');

      return res.status(404).json({
        success: false,
        message: 'User not found.',
      });
    }

    const user = result.rows[0];

    if (!user.is_active) {
      await client.query('ROLLBACK');

      return res.status(403).json({
        success: false,
        message: 'Account is disabled.',
      });
    }

    const currentPasswordCorrect = await verifyPassword(
      user.password_hash,
      currentPassword,
    );

    if (!currentPasswordCorrect) {
      await client.query('ROLLBACK');

      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect.',
      });
    }

    // Do not allow the exact current password to be reused.
    const samePassword = await verifyPassword(
      user.password_hash,
      newPassword,
    );

    if (samePassword) {
      await client.query('ROLLBACK');

      return res.status(400).json({
        success: false,
        message: 'New password must be different from the current password.',
      });
    }

    // Only the Argon2id hash is stored in PostgreSQL.
    const newPasswordHash = await hashPassword(newPassword);

    await client.query(
      `
      UPDATE users
      SET
        password_hash = $1,
        must_change_password = FALSE,
        password_changed_at = NOW(),
        failed_attempts = 0,
        locked_until = NULL,
        updated_at = NOW()
      WHERE id = $2
      `,
      [newPasswordHash, userId],
    );

    // Revoke every refresh-token session for this user.
    await client.query(
      `
      DELETE FROM auth_sessions
      WHERE user_id = $1
      `,
      [userId],
    );

    await client.query('COMMIT');

    return res.status(200).json({
      success: true,
      message: 'Password changed successfully. Please log in again.',
      mustChangePassword: false,
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Change password error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}

module.exports = {
  login,
  changePassword,
};
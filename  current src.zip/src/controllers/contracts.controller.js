const pool = require('../db');

function calculateInterestRate(interval, lifetimeValue) {
  switch (interval) {
    case 'daily':
      return lifetimeValue <= 30 ? 20 : 40;

    case 'weekly':
      if (lifetimeValue <= 4) return 26;
      if (lifetimeValue <= 8) return 35;
      return 40;

    case 'monthly':
      return lifetimeValue <= 4 ? 35 : 40;

    default:
      return null;
  }
}

function roundMoney(value) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}


function parseIsoDateOnly(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return null;
  }

  const [year, month, day] = value.split('-').map(Number);
  const d = new Date(Date.UTC(year, month - 1, day));

  if (
    d.getUTCFullYear() !== year ||
    d.getUTCMonth() !== month - 1 ||
    d.getUTCDate() !== day
  ) {
    return null;
  }

  return { value, year, month, day, utc: d };
}

function isScheduledPaymentDate(
  interval,
  startDateValue,
  targetDateValue,
  lifetimeValue,
) {
  const start = parseIsoDateOnly(startDateValue);
  const target = parseIsoDateOnly(targetDateValue);
  const lifetime = Number(lifetimeValue);

  if (!start || !target) return false;
  if (!Number.isInteger(lifetime) || lifetime <= 0) return false;

  const daysSinceStart = Math.floor(
    (target.utc.getTime() - start.utc.getTime()) / 86400000,
  );

  // The approval/start date itself is NOT a repayment date.
  // This intentionally matches the Penalty/Faini schedule:
  // daily   -> first due date is start + 1 day
  // weekly  -> first due date is start + 7 days
  // monthly -> first due date is start + 1 month
  if (daysSinceStart <= 0) return false;

  switch (interval) {
    case 'daily': {
      return daysSinceStart <= lifetime;
    }

    case 'weekly': {
      if (daysSinceStart % 7 !== 0) return false;
      const installmentNumber = daysSinceStart / 7;
      return installmentNumber >= 1 && installmentNumber <= lifetime;
    }

    case 'monthly': {
      if (target.day !== start.day) return false;

      const monthsSinceStart =
        (target.year - start.year) * 12 + (target.month - start.month);

      return monthsSinceStart >= 1 && monthsSinceStart <= lifetime;
    }

    default:
      return false;
  }
}


async function markExpiredContractsDefaulted(branchId) {
  await pool.query(
    `
    UPDATE contracts
    SET
      status = 'defaulted',
      updated_at = NOW()
    WHERE branch_id = $1
      AND status = 'active'
      AND remaining_debt > 0
      AND contract_start_date IS NOT NULL
      AND (
        (
          payment_interval = 'daily'
          AND NOW() > contract_start_date + make_interval(days => lifetime_value)
        )
        OR
        (
          payment_interval = 'weekly'
          AND NOW() > contract_start_date + make_interval(days => lifetime_value * 7)
        )
        OR
        (
          payment_interval = 'monthly'
          AND NOW() > contract_start_date + make_interval(months => lifetime_value)
        )
      )
    `,
    [branchId],
  );
}

function hasAtLeastThreeNameParts(name) {
  return name
    .trim()
    .split(/\s+/)
    .filter(Boolean).length >= 3;
}

function hasValidBorrowerNameCharacters(name) {
  return /^[\p{L}\p{M}' -]+$/u.test(name);
} 

//phone input validation functions
function normalizeTanzaniaPhone(value) {
  if (typeof value !== 'string') return null;

  // Remove spaces, hyphens and parentheses.
  let phone = value.trim().replace(/[\s\-()]/g, '');

  // +255712345678 -> 255712345678
  if (phone.startsWith('+255')) {
    phone = phone.substring(1);
  }

  // 0712345678 -> 255712345678
  // 0623456789 -> 255623456789
  if (/^0[67]\d{8}$/.test(phone)) {
    phone = `255${phone.substring(1)}`;
  }

  // Final stored format must be 255 + 6/7 + 8 digits.
  if (!/^255[67]\d{8}$/.test(phone)) {
    return null;
  }

  return phone;
}
// it ends here 

async function createContract(req, res) {
  // Only an authenticated Mweka Hazina may submit a contract.
  if (!req.user || req.user.role !== 'officer') {
    return res.status(403).json({
      success: false,
      message: 'Loan officer access is required.',
    });
  }

  const borrowerName =
    typeof req.body.borrowerName === 'string'
      ? req.body.borrowerName.trim().replace(/\s+/g, ' ')
      : '';

  //const phoneNumber =
    //typeof req.body.phoneNumber === 'string'
     //? req.body.phoneNumber.trim()
     // : '';

  const phoneNumber = normalizeTanzaniaPhone(req.body.phoneNumber);   

  const borrowedAmount = Number(req.body.borrowedAmount);

  const interval =
    typeof req.body.interval === 'string'
      ? req.body.interval.trim().toLowerCase()
      : '';

  const lifetimeValue = Number(req.body.lifetimeValue);


//phone number validation proof...............

  if (!borrowerName) {
    return res.status(400).json({
     success: false,
     message: 'Borrower name is required.',
    });
}

if (!phoneNumber) {
   return res.status(400).json({
     success: false,
     message: 'Enter a valid Tanzanian phone number.',
   });
  }


  //names validations.....................................
  if (!hasValidBorrowerNameCharacters(borrowerName)) {
     return res.status(400).json({
     success: false,
     message: 'Borrower name contains invalid characters.',
    });
  }

  if (!hasAtLeastThreeNameParts(borrowerName)) {
    return res.status(400).json({
      success: false,
      message: 'Borrower must have at least three names.',
    });
  }



  if (!Number.isFinite(borrowedAmount) || borrowedAmount <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Borrowed amount must be greater than zero.',
    });
  }

  if (!['daily', 'weekly', 'monthly'].includes(interval)) {
    return res.status(400).json({
      success: false,
      message: 'Payment interval must be daily, weekly or monthly.',
    });
  }

  if (!Number.isInteger(lifetimeValue) || lifetimeValue <= 0) {
    //return res.status(400).json({
      //success: false,
     // message: 'Contract lifetime must be a positive whole number.',
    //});

  return res.status(400).json({
    success: false,
    message: 'Contract lifetime must be a positive whole number.',
   });
 }

 const lifetimeLimits = {
  daily: 60,
  weekly: 12,
  monthly: 8,
 };

 const maxLifetime = lifetimeLimits[interval];

 if (lifetimeValue > maxLifetime) {
  return res.status(400).json({
    success: false,
    message:
      interval === 'daily'
        ? 'Daily contract cannot exceed 60 days.'
        : interval === 'weekly'
          ? 'Weekly contract cannot exceed 12 weeks.'
          : 'Monthly contract cannot exceed 8 months.',
   });

  }

  // Borrowed amount cannot exceed TSH 5,000,000
  if (borrowedAmount > 5000000) {
  return res.status(400).json({
     success: false,
     message: 'Borrowed amount cannot exceed TSH 5,000,000.',
    });
  }



  const interestRate = calculateInterestRate(interval, lifetimeValue);
  const totalDebt = roundMoney(
    borrowedAmount + borrowedAmount * (interestRate / 100),
  );

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // Do not trust officerId or branchId from Flutter. The authenticated user
    // determines both values on the server.
    const officerResult = await client.query(
      `
      SELECT
        u.id,
        u.full_name,
        u.role,
        u.branch_id,
        u.is_active,
        u.must_change_password,
        b.name AS branch_name,
        b.is_active AS branch_is_active
      FROM users AS u
      LEFT JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
      LIMIT 1
      `,
      [req.user.id],
    );

    if (officerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication session.',
      });
    }

    const officer = officerResult.rows[0];

    if (officer.role !== 'officer' || !officer.is_active) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Loan officer account is not available.',
      });
    }

    if (officer.must_change_password) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Change the temporary password before creating contracts.',
      });
    }

    if (!officer.branch_id || !officer.branch_name || !officer.branch_is_active) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Your assigned branch is not available.',
      });
    }

    const insertResult = await client.query(
      `
      INSERT INTO contracts (
        borrower_name,
        phone_number,
        borrowed_amount,
        interest_rate,
        total_debt,
        remaining_debt,
        payment_interval,
        lifetime_value,
        status,
        officer_id,
        branch_id
      )
      VALUES (
        $1,
        $2,
        $3,
        $4,
        $5,
        $5,
        $6,
        $7,
        'pending',
        $8,
        $9
      )
      RETURNING
        id,
        borrower_name,
        phone_number,
        borrowed_amount,
        interest_rate,
        total_debt,
        remaining_debt,
        payment_interval,
        lifetime_value,
        status,
        officer_id,
        branch_id,
        submitted_at,
        created_at,
        updated_at
      `,
      [
        borrowerName,
        phoneNumber,
        borrowedAmount,
        interestRate,
        totalDebt,
        interval,
        lifetimeValue,
        officer.id,
        officer.branch_id,
      ],
    );

    await client.query('COMMIT');

    const contract = insertResult.rows[0];

    return res.status(201).json({
      success: true,
      message: 'Contract submitted for admin approval.',
      contract: {
        id: contract.id,
        borrowerName: contract.borrower_name,
        phoneNumber: contract.phone_number,
        borrowedAmount: Number(contract.borrowed_amount),
        interestRate: Number(contract.interest_rate),
        totalDebt: Number(contract.total_debt),
        remainingDebt: Number(contract.remaining_debt),
        interval: contract.payment_interval,
        lifetimeValue: contract.lifetime_value,
        status: contract.status,
        officerId: contract.officer_id,
        officerName: officer.full_name,
        branchId: contract.branch_id,
        branchName: officer.branch_name,
        submittedAt: contract.submitted_at,
        createdAt: contract.created_at,
        updatedAt: contract.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Create contract error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}


async function listMyContracts(req, res) {
  if (!req.user || req.user.role !== 'officer') {
    return res.status(403).json({
      success: false,
      message: 'Loan officer access is required.',
    });
  }

  try {
    const result = await pool.query(
      `
      SELECT
        c.id,
        c.borrower_name,
        c.phone_number,
        c.borrowed_amount,
        c.interest_rate,
        c.total_debt,
        c.remaining_debt,
        c.payment_interval,
        c.lifetime_value,
        c.status,
        c.officer_id,
        u.full_name AS officer_name,
        c.branch_id,
        b.name AS branch_name,
        c.submitted_at,
        c.contract_start_date,
        c.created_at,
        c.updated_at,
        lp.last_payment_at
      FROM contracts AS c
      INNER JOIN users AS u
        ON u.id = c.officer_id
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      LEFT JOIN LATERAL (
        SELECT MAX(p.paid_at) AS last_payment_at
        FROM payments AS p
        WHERE p.contract_id = c.id
      ) AS lp ON TRUE
      WHERE c.officer_id = $1
        AND c.status IN ('active', 'completed', 'defaulted')
      ORDER BY
        COALESCE(c.contract_start_date, c.created_at) DESC,
        c.id DESC
      `,
      [req.user.id],
    );

    const contracts = result.rows.map((contract) => ({
      id: contract.id,
      borrowerName: contract.borrower_name,
      phoneNumber: contract.phone_number,
      borrowedAmount: Number(contract.borrowed_amount),
      interestRate: Number(contract.interest_rate),
      totalDebt: Number(contract.total_debt),
      remainingDebt: Number(contract.remaining_debt),
      interval: contract.payment_interval,
      lifetimeValue: contract.lifetime_value,
      status: contract.status,
      officerId: contract.officer_id,
      officerName: contract.officer_name,
      branchId: contract.branch_id,
      branchName: contract.branch_name,
      submittedAt: contract.submitted_at,
      contractStartDate: contract.contract_start_date,
      lastPaymentAt: contract.last_payment_at,
      createdAt: contract.created_at,
      updatedAt: contract.updated_at,
    }));

    return res.json({
      success: true,
      contracts,
    });
  } catch (error) {
    console.error('List officer contracts error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}


async function listBranchContracts(req, res) {
  if (!req.user || req.user.role !== 'officer') {
    return res.status(403).json({
      success: false,
      message: 'Loan officer access is required.',
    });
  }

  try {
    // Resolve branch from the authenticated officer. Never trust a branchId
    // supplied by Flutter for branch-wide contract access.
    const officerResult = await pool.query(
      `
      SELECT
        u.id,
        u.role,
        u.branch_id,
        u.is_active,
        u.must_change_password,
        b.name AS branch_name,
        b.opening_balance,
        b.current_balance,
        b.is_active AS branch_is_active
      FROM users AS u
      LEFT JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
      LIMIT 1
      `,
      [req.user.id],
    );

    if (officerResult.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication session.',
      });
    }

    const officer = officerResult.rows[0];

    if (officer.role !== 'officer' || !officer.is_active) {
      return res.status(403).json({
        success: false,
        message: 'Loan officer account is not available.',
      });
    }

    if (officer.must_change_password) {
      return res.status(403).json({
        success: false,
        message: 'Change the temporary password before continuing.',
      });
    }

    if (!officer.branch_id || !officer.branch_name || !officer.branch_is_active) {
      return res.status(409).json({
        success: false,
        message: 'Your assigned branch is not available.',
      });
    }

    // Status changes for expired contracts are authoritative in Neon.
    // Flutter no longer decides that an active contract has become defaulted.
    await markExpiredContractsDefaulted(officer.branch_id);

    const result = await pool.query(
      `
      SELECT
        c.id,
        c.borrower_name,
        c.phone_number,
        c.borrowed_amount,
        c.interest_rate,
        c.total_debt,
        c.remaining_debt,
        c.payment_interval,
        c.lifetime_value,
        c.status,
        c.officer_id,
        u.full_name AS officer_name,
        c.branch_id,
        b.name AS branch_name,
        c.submitted_at,
        c.contract_start_date,
        c.created_at,
        c.updated_at,
        lp.last_payment_at
      FROM contracts AS c
      INNER JOIN users AS u
        ON u.id = c.officer_id
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      LEFT JOIN LATERAL (
        SELECT MAX(p.paid_at) AS last_payment_at
        FROM payments AS p
        WHERE p.contract_id = c.id
      ) AS lp ON TRUE
      WHERE c.branch_id = $1
        AND c.status IN ('active', 'completed', 'defaulted')
      ORDER BY
        COALESCE(c.contract_start_date, c.created_at) DESC,
        c.id DESC
      `,
      [officer.branch_id],
    );

    const contracts = result.rows.map((contract) => ({
      id: contract.id,
      borrowerName: contract.borrower_name,
      phoneNumber: contract.phone_number,
      borrowedAmount: Number(contract.borrowed_amount),
      interestRate: Number(contract.interest_rate),
      totalDebt: Number(contract.total_debt),
      remainingDebt: Number(contract.remaining_debt),
      interval: contract.payment_interval,
      lifetimeValue: contract.lifetime_value,
      status: contract.status,
      officerId: contract.officer_id,
      officerName: contract.officer_name,
      branchId: contract.branch_id,
      branchName: contract.branch_name,
      submittedAt: contract.submitted_at,
      contractStartDate: contract.contract_start_date,
      lastPaymentAt: contract.last_payment_at,
      createdAt: contract.created_at,
      updatedAt: contract.updated_at,
    }));

    return res.json({
      success: true,
      branch: {
        id: Number(officer.branch_id),
        name: officer.branch_name,
        openingBalance: Number(officer.opening_balance),
        currentBalance: Number(officer.current_balance),
      },
      contracts,
    });
  } catch (error) {
    console.error('List branch contracts error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}



async function listMissedReturnsByDate(req, res) {
  if (!req.user || req.user.role !== 'officer') {
    return res.status(403).json({
      success: false,
      message: 'Loan officer access is required.',
    });
  }

  const selectedDate = parseIsoDateOnly(req.query.date);

  if (!selectedDate) {
    return res.status(400).json({
      success: false,
      message: 'A valid date is required.',
    });
  }

  try {
    const officerResult = await pool.query(
      `
      SELECT
        u.id,
        u.role,
        u.branch_id,
        u.is_active,
        u.must_change_password,
        b.name AS branch_name,
        b.is_active AS branch_is_active,
        TO_CHAR(
          NOW() AT TIME ZONE 'Africa/Dar_es_Salaam',
          'YYYY-MM-DD'
        ) AS today_local
      FROM users AS u
      LEFT JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
      LIMIT 1
      `,
      [req.user.id],
    );

    if (officerResult.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication session.',
      });
    }

    const officer = officerResult.rows[0];

    if (officer.role !== 'officer' || !officer.is_active) {
      return res.status(403).json({
        success: false,
        message: 'Loan officer account is not available.',
      });
    }

    if (officer.must_change_password) {
      return res.status(403).json({
        success: false,
        message: 'Change the temporary password before continuing.',
      });
    }

    if (!officer.branch_id || !officer.branch_name || !officer.branch_is_active) {
      return res.status(409).json({
        success: false,
        message: 'Your assigned branch is not available.',
      });
    }

    if (selectedDate.value > officer.today_local) {
      return res.status(400).json({
        success: false,
        message: 'Future dates are not available.',
      });
    }

    const result = await pool.query(
      `
      SELECT
        c.id,
        c.borrower_name,
        c.phone_number,
        c.borrowed_amount,
        c.interest_rate,
        c.total_debt,
        c.remaining_debt,
        c.payment_interval,
        c.lifetime_value,
        c.status,
        c.officer_id,
        creator.full_name AS officer_name,
        c.branch_id,
        b.name AS branch_name,
        c.submitted_at,
        c.contract_start_date,
        c.created_at,
        c.updated_at,
        TO_CHAR(
          c.contract_start_date AT TIME ZONE 'Africa/Dar_es_Salaam',
          'YYYY-MM-DD'
        ) AS contract_start_date_local,
        COALESCE(pay.paid_before_date, 0) AS paid_before_date,
        COALESCE(pay.payment_count_on_date, 0) AS payment_count_on_date,
        pay.last_payment_at
      FROM contracts AS c
      INNER JOIN users AS creator
        ON creator.id = c.officer_id
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      LEFT JOIN LATERAL (
        SELECT
          COALESCE(
            SUM(p.amount) FILTER (
              WHERE (p.paid_at AT TIME ZONE 'Africa/Dar_es_Salaam')::date < $2::date
            ),
            0
          ) AS paid_before_date,
          COUNT(*) FILTER (
            WHERE (p.paid_at AT TIME ZONE 'Africa/Dar_es_Salaam')::date = $2::date
          ) AS payment_count_on_date,
          MAX(p.paid_at) AS last_payment_at
        FROM payments AS p
        WHERE p.contract_id = c.id
      ) AS pay ON TRUE
      WHERE c.branch_id = $1
        AND c.contract_start_date IS NOT NULL
        AND (c.contract_start_date AT TIME ZONE 'Africa/Dar_es_Salaam')::date <= $2::date
        AND c.status IN ('active', 'completed', 'defaulted')
      ORDER BY c.borrower_name ASC, c.id ASC
      `,
      [officer.branch_id, selectedDate.value],
    );

    const contracts = result.rows
      .filter((contract) => {
        const totalDebt = Number(contract.total_debt);
        const paidBeforeDate = Number(contract.paid_before_date);
        const paymentCountOnDate = Number(contract.payment_count_on_date);

        // If the debt had already been fully settled before this date,
        // the borrower was no longer expected to pay on the selected date.
        if (
          Number.isFinite(totalDebt) &&
          Number.isFinite(paidBeforeDate) &&
          paidBeforeDate >= totalDebt - 0.005
        ) {
          return false;
        }

        // Any payment recorded on this exact Tanzania-local date means the
        // borrower did not miss that scheduled payment date.
        if (paymentCountOnDate > 0) return false;

        return isScheduledPaymentDate(
          contract.payment_interval,
          contract.contract_start_date_local,
          selectedDate.value,
          contract.lifetime_value,
        );
      })
      .map((contract) => ({
        id: contract.id,
        borrowerName: contract.borrower_name,
        phoneNumber: contract.phone_number,
        borrowedAmount: Number(contract.borrowed_amount),
        interestRate: Number(contract.interest_rate),
        totalDebt: Number(contract.total_debt),
        remainingDebt: Number(contract.remaining_debt),
        interval: contract.payment_interval,
        lifetimeValue: contract.lifetime_value,
        status: contract.status,
        officerId: contract.officer_id,
        officerName: contract.officer_name,
        branchId: contract.branch_id,
        branchName: contract.branch_name,
        submittedAt: contract.submitted_at,
        contractStartDate: contract.contract_start_date,
        lastPaymentAt: contract.last_payment_at,
        createdAt: contract.created_at,
        updatedAt: contract.updated_at,
      }));

    return res.json({
      success: true,
      date: selectedDate.value,
      branch: {
        id: Number(officer.branch_id),
        name: officer.branch_name,
      },
      count: contracts.length,
      contracts,
    });
  } catch (error) {
    console.error('List missed returns by date error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}



async function listReturnsByDate(req, res) {
  if (!req.user || req.user.role !== 'officer') {
    return res.status(403).json({
      success: false,
      message: 'Loan officer access is required.',
    });
  }

  const selectedDate = parseIsoDateOnly(req.query.date);

  if (!selectedDate) {
    return res.status(400).json({
      success: false,
      message: 'A valid date is required.',
    });
  }

  try {
    const officerResult = await pool.query(
      `
      SELECT
        u.id,
        u.role,
        u.branch_id,
        u.is_active,
        u.must_change_password,
        b.name AS branch_name,
        b.is_active AS branch_is_active,
        TO_CHAR(
          NOW() AT TIME ZONE 'Africa/Dar_es_Salaam',
          'YYYY-MM-DD'
        ) AS today_local
      FROM users AS u
      LEFT JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
      LIMIT 1
      `,
      [req.user.id],
    );

    if (officerResult.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication session.',
      });
    }

    const officer = officerResult.rows[0];

    if (officer.role !== 'officer' || !officer.is_active) {
      return res.status(403).json({
        success: false,
        message: 'Loan officer account is not available.',
      });
    }

    if (officer.must_change_password) {
      return res.status(403).json({
        success: false,
        message: 'Change the temporary password before continuing.',
      });
    }

    if (!officer.branch_id || !officer.branch_name || !officer.branch_is_active) {
      return res.status(409).json({
        success: false,
        message: 'Your assigned branch is not available.',
      });
    }

    if (selectedDate.value > officer.today_local) {
      return res.status(400).json({
        success: false,
        message: 'Future dates are not available.',
      });
    }

    const result = await pool.query(
      `
      SELECT
        p.id,
        p.contract_id,
        c.borrower_name,
        c.phone_number,
        p.branch_id,
        b.name AS branch_name,
        p.amount,
        p.paid_at,
        p.recorded_by,
        recorder.full_name AS recorded_by_name,
        c.officer_id AS contract_officer_id,
        creator.full_name AS contract_officer_name
      FROM payments AS p
      INNER JOIN contracts AS c
        ON c.id = p.contract_id
      INNER JOIN branches AS b
        ON b.id = p.branch_id
      INNER JOIN users AS recorder
        ON recorder.id = p.recorded_by
      INNER JOIN users AS creator
        ON creator.id = c.officer_id
      WHERE p.branch_id = $1
        AND (p.paid_at AT TIME ZONE 'Africa/Dar_es_Salaam')::date = $2::date
      ORDER BY p.paid_at DESC, p.id DESC
      `,
      [officer.branch_id, selectedDate.value],
    );

    const payments = result.rows.map((payment) => ({
      id: payment.id,
      contractId: payment.contract_id,
      borrowerName: payment.borrower_name,
      phoneNumber: payment.phone_number,
      branchId: Number(payment.branch_id),
      branchName: payment.branch_name,
      amount: Number(payment.amount),
      paidAt: payment.paid_at,
      recordedBy: payment.recorded_by,
      recordedByName: payment.recorded_by_name,
      contractOfficerId: payment.contract_officer_id,
      contractOfficerName: payment.contract_officer_name,
    }));

    const totalAmount = payments.reduce(
      (sum, payment) => sum + payment.amount,
      0,
    );

    return res.json({
      success: true,
      date: selectedDate.value,
      branch: {
        id: Number(officer.branch_id),
        name: officer.branch_name,
      },
      count: payments.length,
      totalAmount: roundMoney(totalAmount),
      payments,
    });
  } catch (error) {
    console.error('List returns by date error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}



function formatUtcDate(date) {
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  const day = String(date.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function addUtcDays(dateString, days) {
  const parsed = parseIsoDateOnly(dateString);
  if (!parsed) return null;

  const d = new Date(parsed.utc.getTime());
  d.setUTCDate(d.getUTCDate() + days);
  return formatUtcDate(d);
}

function addUtcMonthsSameDay(dateString, months) {
  const parsed = parseIsoDateOnly(dateString);
  if (!parsed) return null;

  const targetMonthIndex = parsed.month - 1 + months;
  const targetYear = parsed.year + Math.floor(targetMonthIndex / 12);
  const normalizedMonth = ((targetMonthIndex % 12) + 12) % 12;
  const d = new Date(Date.UTC(targetYear, normalizedMonth, parsed.day));

  // Keep the same day-of-month semantics already used by Hawajarejesha.
  // Example: a contract starting on the 31st has no scheduled date in a
  // month that does not contain a 31st.
  if (
    d.getUTCFullYear() !== targetYear ||
    d.getUTCMonth() !== normalizedMonth ||
    d.getUTCDate() !== parsed.day
  ) {
    return null;
  }

  return formatUtcDate(d);
}

function buildContractDueDates(interval, startDateLocal, lifetimeValue, throughDate) {
  const dates = [];

  if (!parseIsoDateOnly(startDateLocal) || !parseIsoDateOnly(throughDate)) {
    return dates;
  }

  // The approval/start date itself is not a repayment date.
  // Daily: first payment is next day.
  // Weekly: first payment is 7 days later.
  // Monthly: first payment is 1 month later.
  for (let installment = 1; installment <= lifetimeValue; installment += 1) {
    let dueDate = null;

    if (interval === 'daily') {
      dueDate = addUtcDays(startDateLocal, installment);
    } else if (interval === 'weekly') {
      dueDate = addUtcDays(startDateLocal, installment * 7);
    } else if (interval === 'monthly') {
      dueDate = addUtcMonthsSameDay(startDateLocal, installment);
    }

    if (!dueDate) continue;
    if (dueDate > throughDate) break;

    dates.push(dueDate);
  }

  return dates;
}

async function generateMissingPenaltiesForBranch(client, branchId, throughDate) {
  const contractResult = await client.query(
    `
    SELECT
      c.id,
      c.total_debt,
      c.payment_interval,
      c.lifetime_value,
      TO_CHAR(
        c.contract_start_date AT TIME ZONE 'Africa/Dar_es_Salaam',
        'YYYY-MM-DD'
      ) AS contract_start_date_local
    FROM contracts AS c
    WHERE c.branch_id = $1
      AND c.contract_start_date IS NOT NULL
      AND c.status IN ('active', 'completed', 'defaulted')
    ORDER BY c.id ASC
    `,
    [branchId],
  );

  if (contractResult.rows.length === 0) return 0;

  const contractIds = contractResult.rows.map((row) => row.id);

  const paymentsResult = await client.query(
    `
    SELECT
      p.contract_id,
      p.amount,
      TO_CHAR(
        p.paid_at AT TIME ZONE 'Africa/Dar_es_Salaam',
        'YYYY-MM-DD'
      ) AS paid_date_local
    FROM payments AS p
    WHERE p.contract_id = ANY($1::bigint[])
    ORDER BY p.contract_id ASC, p.paid_at ASC, p.id ASC
    `,
    [contractIds],
  );

  const paymentsByContract = new Map();

  for (const payment of paymentsResult.rows) {
    const key = String(payment.contract_id);
    if (!paymentsByContract.has(key)) paymentsByContract.set(key, []);
    paymentsByContract.get(key).push({
      date: payment.paid_date_local,
      amount: Number(payment.amount),
    });
  }

  let generatedCount = 0;

  for (const contract of contractResult.rows) {
    const totalDebt = Number(contract.total_debt);
    const lifetimeValue = Number(contract.lifetime_value);

    if (!Number.isFinite(totalDebt) || totalDebt <= 0) continue;
    if (!Number.isInteger(lifetimeValue) || lifetimeValue <= 0) continue;

    const dueDates = buildContractDueDates(
      contract.payment_interval,
      contract.contract_start_date_local,
      lifetimeValue,
      throughDate,
    );

    const payments = paymentsByContract.get(String(contract.id)) || [];

    for (const dueDate of dueDates) {
      let paidBeforeDate = 0;
      let paymentOnDate = false;

      for (const payment of payments) {
        if (payment.date < dueDate) {
          paidBeforeDate += payment.amount;
        } else if (payment.date === dueDate) {
          paymentOnDate = true;
        }
      }

      // If the contract was already fully paid before this due date,
      // the borrower had no repayment obligation for that date.
      if (paidBeforeDate >= totalDebt - 0.005) {
        continue;
      }

      // Any Rejesho recorded on the exact scheduled date counts as paid
      // for penalty purposes, matching the existing Hawajarejesha rule.
      if (paymentOnDate) {
        continue;
      }

      const inserted = await client.query(
        `
        INSERT INTO penalty_events (
          contract_id,
          branch_id,
          due_date,
          amount,
          status
        )
        VALUES ($1, $2, $3::date, 2000, 'open')
        ON CONFLICT (contract_id, due_date) DO NOTHING
        RETURNING id
        `,
        [contract.id, branchId, dueDate],
      );

      if (inserted.rows.length > 0) {
        generatedCount += 1;
      }
    }
  }

  return generatedCount;
}

async function listPenalties(req, res) {
  if (!req.user || req.user.role !== 'officer') {
    return res.status(403).json({
      success: false,
      message: 'Loan officer access is required.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const officerResult = await client.query(
      `
      SELECT
        u.id,
        u.role,
        u.branch_id,
        u.is_active,
        u.must_change_password,
        b.name AS branch_name,
        b.is_active AS branch_is_active,
        TO_CHAR(
          NOW() AT TIME ZONE 'Africa/Dar_es_Salaam',
          'YYYY-MM-DD'
        ) AS today_local
      FROM users AS u
      LEFT JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
      LIMIT 1
      `,
      [req.user.id],
    );

    if (officerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication session.',
      });
    }

    const officer = officerResult.rows[0];

    if (officer.role !== 'officer' || !officer.is_active) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Loan officer account is not available.',
      });
    }

    if (officer.must_change_password) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Change the temporary password before continuing.',
      });
    }

    if (!officer.branch_id || !officer.branch_name || !officer.branch_is_active) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Your assigned branch is not available.',
      });
    }

    // Penalties are generated only after a repayment date has fully passed.
    // Therefore, on 5 Sept the latest date that can become a penalty is 4 Sept.
    const throughDate = addUtcDays(officer.today_local, -1);

    const generatedCount = await generateMissingPenaltiesForBranch(
      client,
      officer.branch_id,
      throughDate,
    );

    const penaltyResult = await client.query(
      `
      SELECT
        pe.id AS penalty_event_id,
        pe.due_date,
        pe.amount,
        pe.created_at,
        c.id AS contract_id,
        c.borrower_name,
        c.phone_number,
        c.remaining_debt,
        c.payment_interval,
        c.lifetime_value,
        c.status AS contract_status,
        c.officer_id,
        creator.full_name AS officer_name,
        c.branch_id,
        b.name AS branch_name
      FROM penalty_events AS pe
      INNER JOIN contracts AS c
        ON c.id = pe.contract_id
      INNER JOIN branches AS b
        ON b.id = pe.branch_id
      INNER JOIN users AS creator
        ON creator.id = c.officer_id
      WHERE pe.branch_id = $1
        AND pe.status = 'open'
      ORDER BY c.borrower_name ASC, pe.due_date ASC, pe.id ASC
      `,
      [officer.branch_id],
    );

    const grouped = new Map();

    for (const row of penaltyResult.rows) {
      const key = String(row.contract_id);

      if (!grouped.has(key)) {
        grouped.set(key, {
          contractId: row.contract_id,
          borrowerName: row.borrower_name,
          phoneNumber: row.phone_number,
          remainingDebt: Number(row.remaining_debt),
          interval: row.payment_interval,
          lifetimeValue: row.lifetime_value,
          contractStatus: row.contract_status,
          officerId: row.officer_id,
          officerName: row.officer_name,
          branchId: Number(row.branch_id),
          branchName: row.branch_name,
          missedPaymentCount: 0,
          totalPenaltyAmount: 0,
          events: [],
        });
      }

      const group = grouped.get(key);
      group.missedPaymentCount += 1;
      group.totalPenaltyAmount = roundMoney(
        group.totalPenaltyAmount + Number(row.amount),
      );
      group.events.push({
        id: row.penalty_event_id,
        dueDate: row.due_date,
        amount: Number(row.amount),
        createdAt: row.created_at,
      });
    }

    await client.query('COMMIT');

    const penalties = Array.from(grouped.values());
    const totalOutstandingPenalty = roundMoney(
      penalties.reduce((sum, item) => sum + item.totalPenaltyAmount, 0),
    );

    return res.json({
      success: true,
      branch: {
        id: Number(officer.branch_id),
        name: officer.branch_name,
      },
      generatedThroughDate: throughDate,
      newlyGeneratedCount: generatedCount,
      customerCount: penalties.length,
      totalOutstandingPenalty,
      penalties,
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('List penalties error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}


async function settlePenalty(req, res) {
  if (!req.user || req.user.role !== 'officer') {
    return res.status(403).json({
      success: false,
      message: 'Loan officer access is required.',
    });
  }

  const contractId = Number(req.params.contractId);
  const amountPaid = Number(req.body.amount);
  const note = typeof req.body.note === 'string'
    ? req.body.note.trim()
    : null;

  if (note && note.length > 500) {
     return res.status(400).json({
      success: false,
      message: 'Maelezo ya faini hayawezi kuzidi herufi 500.',
    });
  }

  if (!Number.isInteger(contractId) || contractId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid contract.',
    });
  }

  if (!Number.isFinite(amountPaid) || amountPaid <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Malipo ya Faini lazima sio sahihi ( usiandike 0 ).',
    });
  }

  if (!Number.isInteger(amountPaid)) {
    return res.status(400).json({
      success: false,
      message: 'Kiasi cha faini lazima kiwe katika shilingi kamili.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const officerResult = await client.query(
      `
      SELECT
        u.id,
        u.full_name,
        u.role,
        u.branch_id,
        u.is_active,
        u.must_change_password,
        b.name AS branch_name,
        b.is_active AS branch_is_active,
        TO_CHAR(
          NOW() AT TIME ZONE 'Africa/Dar_es_Salaam',
          'YYYY-MM-DD'
        ) AS today_local
      FROM users AS u
      LEFT JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
      LIMIT 1
      `,
      [req.user.id],
    );

    if (officerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication session.',
      });
    }

    const officer = officerResult.rows[0];

    if (officer.role !== 'officer' || !officer.is_active) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Loan officer account is not available.',
      });
    }

    if (officer.must_change_password) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Change the temporary password before continuing.',
      });
    }

    if (!officer.branch_id || !officer.branch_name || !officer.branch_is_active) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Your assigned branch is not available.',
      });
    }

    const contractResult = await client.query(
      `
      SELECT
        c.id,
        c.borrower_name,
        c.phone_number,
        c.branch_id,
        b.name AS branch_name
      FROM contracts AS c
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      WHERE c.id = $1
      LIMIT 1
      `,
      [contractId],
    );

    if (contractResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Contract was not found.',
      });
    }

    const contract = contractResult.rows[0];

    if (String(contract.branch_id) !== String(officer.branch_id)) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'This contract belongs to another branch.',
      });
    }

    // Before settling, generate any missed scheduled-payment penalties through
    // yesterday so the amount being settled cannot omit a historical miss.
    const throughDate = addUtcDays(officer.today_local, -1);
    await generateMissingPenaltiesForBranch(
      client,
      officer.branch_id,
      throughDate,
    );

    // Lock every currently-open event for this contract. This prevents two
    // officers in the same branch from settling the same penalties twice.
    const openEventsResult = await client.query(
      `
      SELECT
        id,
        due_date,
        amount,
        created_at
      FROM penalty_events
      WHERE contract_id = $1
        AND branch_id = $2
        AND status = 'open'
      ORDER BY due_date ASC, id ASC
      FOR UPDATE
      `,
      [contract.id, officer.branch_id],
    );

    if (openEventsResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'There is no outstanding penalty for this contract.',
      });
    }

    const totalPenaltyAmount = roundMoney(
      openEventsResult.rows.reduce(
        (sum, row) => sum + Number(row.amount),
        0,
      ),
    );

    if (amountPaid > totalPenaltyAmount + 0.005) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        success: false,
        message: 'Penalty payment cannot be greater than the outstanding penalty.',
        totalPenaltyAmount,
      });
    }

    const normalizedAmountPaid = roundMoney(amountPaid);
    const amountWaived = roundMoney(
      totalPenaltyAmount - normalizedAmountPaid,
    );

    const settlementResult = await client.query(
      `
      INSERT INTO penalty_settlements (
        contract_id,
        branch_id,
        total_penalty_amount,
        amount_paid,
        amount_waived,
        recorded_by,
        note
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING
        id,
        contract_id,
        branch_id,
        total_penalty_amount,
        amount_paid,
        amount_waived,
        recorded_by,
        note,
        settled_at
      `,
      [
        contract.id,
        officer.branch_id,
        totalPenaltyAmount,
        normalizedAmountPaid,
        amountWaived,
        officer.id,
        note || null,
      ],
    );

    const settlement = settlementResult.rows[0];
    const eventIds = openEventsResult.rows.map((row) => row.id);

    await client.query(
      `
      UPDATE penalty_events
      SET
        status = 'settled',
        settlement_id = $1,
        settled_at = $2
      WHERE id = ANY($3::bigint[])
      `,
      [settlement.id, settlement.settled_at, eventIds],
    );

    // Faini is a separate collection. It must NEVER replenish the branch
    // loan-fund/current balance.
    const branchResult = await client.query(
      `
      SELECT current_balance
      FROM branches
      WHERE id = $1
      LIMIT 1
      `,
      [officer.branch_id],
    );

    await client.query('COMMIT');

    return res.status(201).json({
      success: true,
      message: 'Penalty settled successfully.',
      settlement: {
        id: settlement.id,
        contractId: settlement.contract_id,
        borrowerName: contract.borrower_name,
        phoneNumber: contract.phone_number,
        branchId: Number(settlement.branch_id),
        branchName: contract.branch_name,
        totalPenaltyAmount: Number(settlement.total_penalty_amount),
        amountPaid: Number(settlement.amount_paid),
        amountWaived: Number(settlement.amount_waived),
        settledEventCount: eventIds.length,
        recordedBy: settlement.recorded_by,
        recordedByName: officer.full_name,
        note: settlement.note,
        settledAt: settlement.settled_at,
      },
      settledEvents: openEventsResult.rows.map((row) => ({
        id: row.id,
        dueDate: row.due_date,
        amount: Number(row.amount),
      })),
      branchCurrentBalance: Number(branchResult.rows[0].current_balance),
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Settle penalty error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}

async function recordPayment(req, res) {
  if (!req.user || req.user.role !== 'officer') {
    return res.status(403).json({
      success: false,
      message: 'Loan officer access is required.',
    });
  }

  const contractId = Number(req.params.contractId);
  const amount = Number(req.body.amount);

  if (!Number.isInteger(contractId) || contractId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid contract id.',
    });
  }

  if (!Number.isFinite(amount) || amount <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Malipo sio sahihi. Usiandike sifuri. Karibu tena.',
    });
  }

  if (!Number.isInteger(amount)) {
    return res.status(400).json({
      success: false,
      message: 'Kiasi cha rejesho lazima kiwe katika shilingi kamili.',
    });
  }

  const paymentAmount = roundMoney(amount);
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // Resolve the branch from the authenticated officer. Flutter is never
    // trusted to choose the branch or the officer who records the payment.
    const officerResult = await client.query(
      `
      SELECT
        u.id,
        u.full_name,
        u.role,
        u.branch_id,
        u.is_active,
        u.must_change_password,
        b.name AS branch_name,
        b.current_balance,
        b.is_active AS branch_is_active
      FROM users AS u
      LEFT JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
      LIMIT 1
      `,
      [req.user.id],
    );

    if (officerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(401).json({
        success: false,
        message: 'Invalid authentication session.',
      });
    }

    const officer = officerResult.rows[0];

    if (officer.role !== 'officer' || !officer.is_active) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Loan officer account is not available.',
      });
    }

    if (officer.must_change_password) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'Change the temporary password before continuing.',
      });
    }

    if (!officer.branch_id || !officer.branch_name || !officer.branch_is_active) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Your assigned branch is not available.',
      });
    }

    // Lock the contract so two officers cannot update the same remaining debt
    // at the same time. Any officer in the SAME branch may record a Rejesho.
    const contractResult = await client.query(
      `
      SELECT
        c.id,
        c.borrower_name,
        c.phone_number,
        c.borrowed_amount,
        c.interest_rate,
        c.total_debt,
        c.remaining_debt,
        c.payment_interval,
        c.lifetime_value,
        c.status,
        c.officer_id,
        creator.full_name AS officer_name,
        c.branch_id,
        b.name AS branch_name,
        c.submitted_at,
        c.contract_start_date,
        TO_CHAR(
          c.contract_start_date AT TIME ZONE 'Africa/Dar_es_Salaam',
          'YYYY-MM-DD'
        ) AS contract_start_date_local,
        TO_CHAR(
          NOW() AT TIME ZONE 'Africa/Dar_es_Salaam',
          'YYYY-MM-DD'
        ) AS today_local,
        c.created_at,
        c.updated_at
      FROM contracts AS c
      INNER JOIN users AS creator
        ON creator.id = c.officer_id
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      WHERE c.id = $1
      LIMIT 1
      FOR UPDATE OF c
      `,
      [contractId],
    );

    if (contractResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Contract was not found.',
      });
    }

    const contract = contractResult.rows[0];

    if (String(contract.branch_id) !== String(officer.branch_id)) {
      await client.query('ROLLBACK');
      return res.status(403).json({
        success: false,
        message: 'This contract belongs to another branch.',
      });
    }

    if (!['active', 'defaulted'].includes(contract.status)) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: contract.status === 'completed'
          ? 'This contract is already completed.'
          : 'This contract is not ready for payments.',
      });
    }

    const remainingDebt = Number(contract.remaining_debt);

    if (!Number.isFinite(remainingDebt) || remainingDebt <= 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'This contract has no remaining debt.',
      });
    }

    if (paymentAmount > remainingDebt) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        success: false,
        message: 'Payment amount is greater than the remaining debt.',
        remainingDebt,
      });
    }

    // A newly approved contract cannot receive Rejesho on the approval day.
    // The first payment becomes eligible only after the first scheduled due
    // date has arrived. This matches Hawajarejesha and Penalty/Faini:
    // daily   -> start + 1 day
    // weekly  -> start + 7 days
    // monthly -> first valid same-day date in a later month
    const dueDatesThroughToday = buildContractDueDates(
      contract.payment_interval,
      contract.contract_start_date_local,
      Number(contract.lifetime_value),
      contract.today_local,
    );

    if (dueDatesThroughToday.length === 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        code: 'PAYMENT_NOT_DUE_YET',
        message: 'Rejesho bado halijafika kwa mkataba huu.',
      });
    }

    // Enforce the same interval rule on the server so a modified APK cannot
    // submit multiple Rejesho transactions inside one interval.
    const latestPaymentResult = await client.query(
      `
      SELECT
        paid_at,
        CASE
          WHEN $2 = 'daily' THEN
            (paid_at AT TIME ZONE 'Africa/Dar_es_Salaam')::date =
            (NOW() AT TIME ZONE 'Africa/Dar_es_Salaam')::date
          WHEN $2 = 'weekly' THEN
            paid_at > NOW() - INTERVAL '7 days'
          WHEN $2 = 'monthly' THEN
            DATE_TRUNC('month', paid_at AT TIME ZONE 'Africa/Dar_es_Salaam') =
            DATE_TRUNC('month', NOW() AT TIME ZONE 'Africa/Dar_es_Salaam')
          ELSE TRUE
        END AS interval_blocked
      FROM payments
      WHERE contract_id = $1
      ORDER BY paid_at DESC, id DESC
      LIMIT 1
      `,
      [contract.id, contract.payment_interval],
    );

    if (
      latestPaymentResult.rows.length > 0 &&
      latestPaymentResult.rows[0].interval_blocked === true
    ) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'A payment has already been recorded for the current interval.',
        lastPaymentAt: latestPaymentResult.rows[0].paid_at,
      });
    }

    const newRemainingDebt = roundMoney(remainingDebt - paymentAmount);
    const newStatus = newRemainingDebt <= 0 ? 'completed' : contract.status;

    const paymentResult = await client.query(
      `
      INSERT INTO payments (
        contract_id,
        branch_id,
        recorded_by,
        amount
      )
      VALUES ($1, $2, $3, $4)
      RETURNING
        id,
        contract_id,
        branch_id,
        recorded_by,
        amount,
        paid_at,
        created_at
      `,
      [contract.id, contract.branch_id, officer.id, paymentAmount],
    );

    const updatedContractResult = await client.query(
      `
      UPDATE contracts
      SET
        remaining_debt = $1,
        status = $2,
        updated_at = NOW()
      WHERE id = $3
      RETURNING
        id,
        remaining_debt,
        status,
        updated_at
      `,
      [newRemainingDebt, newStatus, contract.id],
    );

    // Rejesho is recorded as a collection/payment only. It reduces the
    // customer's remaining debt, but it does NOT change the branch loan-fund balance.
    const branchResult = await client.query(
      `
      SELECT current_balance
      FROM branches
      WHERE id = $1
      LIMIT 1
      `,
      [contract.branch_id],
    );

    await client.query('COMMIT');

    const payment = paymentResult.rows[0];
    const updatedContract = updatedContractResult.rows[0];

    return res.status(201).json({
      success: true,
      message: 'Payment recorded successfully.',
      payment: {
        id: payment.id,
        contractId: payment.contract_id,
        borrowerName: contract.borrower_name,
        branchId: Number(payment.branch_id),
        branchName: contract.branch_name,
        amount: Number(payment.amount),
        paidAt: payment.paid_at,
        recordedBy: payment.recorded_by,
        recordedByName: officer.full_name,
      },
      contract: {
        id: contract.id,
        borrowerName: contract.borrower_name,
        phoneNumber: contract.phone_number,
        borrowedAmount: Number(contract.borrowed_amount),
        interestRate: Number(contract.interest_rate),
        totalDebt: Number(contract.total_debt),
        remainingDebt: Number(updatedContract.remaining_debt),
        interval: contract.payment_interval,
        lifetimeValue: contract.lifetime_value,
        status: updatedContract.status,
        officerId: contract.officer_id,
        officerName: contract.officer_name,
        branchId: contract.branch_id,
        branchName: contract.branch_name,
        submittedAt: contract.submitted_at,
        contractStartDate: contract.contract_start_date,
        lastPaymentAt: payment.paid_at,
        updatedAt: updatedContract.updated_at,
      },
      branchCurrentBalance: Number(branchResult.rows[0].current_balance),
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Record payment error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}

module.exports = {
  createContract,
  listMyContracts,
  listBranchContracts,
  listMissedReturnsByDate,
  listReturnsByDate,
  listPenalties,
  settlePenalty,
  recordPayment,
};

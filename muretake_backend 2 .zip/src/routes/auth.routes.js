const express = require('express');

const {
  login,
  changePassword,
  logout,
} = require('../controllers/auth.controller');

const {
  requireAuth,
} = require('../middleware/auth.middleware');

const {
  loginLimiter,
} = require('../middleware/rateLimit.middleware');

const router = express.Router();

router.post(
  '/login',
  loginLimiter,
  login,
);


router.post(
  '/logout',
  requireAuth,
  logout,
);

router.post(
  '/change-password',
  requireAuth,
  changePassword,
);

module.exports = router;

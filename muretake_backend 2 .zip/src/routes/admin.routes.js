const express = require('express');

const {
  getDashboardSummary,
  getAdminOverview,
  listAdminContracts,
  listAdminPenalties,
  createOfficer,
  listOfficers,
  setOfficerStatus,
  updateOfficer,
  resetOfficerPassword,
  listBranches,
  createBranch,
  updateBranch,
  setBranchStatus,
  topUpBranchBalance,
  adjustBranchBalance,
  listBranchBalanceHistory,
  listPendingContracts,
  approveContract,
  rejectContract,
} = require('../controllers/admin.controller');

const {
  sensitiveActionLimiter,
} = require('../middleware/rateLimit.middleware');

const { requireAuth } = require('../middleware/auth.middleware');

const router = express.Router();

router.get('/dashboard', requireAuth, getDashboardSummary);
router.get('/overview', requireAuth, getAdminOverview);
router.get('/contracts', requireAuth, listAdminContracts);
router.get('/penalties', requireAuth, listAdminPenalties);

router.get('/officers', requireAuth, listOfficers);
router.post('/officers', requireAuth, createOfficer);
router.patch('/officers/:officerId', requireAuth, updateOfficer);
router.patch('/officers/:officerId/status', requireAuth, setOfficerStatus);
router.patch('/officers/:officerId/reset-password', requireAuth, resetOfficerPassword);

router.get('/branches', requireAuth, listBranches);
router.post('/branches', requireAuth, createBranch);
router.patch('/branches/:branchId', requireAuth, updateBranch);
router.patch('/branches/:branchId/status', requireAuth, setBranchStatus);
router.post('/branches/:branchId/top-up', requireAuth, topUpBranchBalance);
router.post('/branches/:branchId/adjust-balance', requireAuth, adjustBranchBalance);
router.get('/branches/:branchId/balance-history', requireAuth, listBranchBalanceHistory);

router.get('/contracts/pending', requireAuth, listPendingContracts);
router.patch('/contracts/:contractId/approve', requireAuth, sensitiveActionLimiter, approveContract);
router.patch('/contracts/:contractId/reject', requireAuth, sensitiveActionLimiter, rejectContract);

module.exports = router;

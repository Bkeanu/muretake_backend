const crypto = require('crypto');
const jwt = require('jsonwebtoken');

function createAccessToken(user, sessionId) {
  if (!process.env.JWT_ACCESS_SECRET) {
    throw new Error('JWT_ACCESS_SECRET is missing');
  }

  if (!sessionId) {
    throw new Error('sessionId is required');
  }

  return jwt.sign(
    {
      role: user.role,
      branchId: user.branch_id,
      sid: sessionId,
    },
    process.env.JWT_ACCESS_SECRET,
    {
      subject: String(user.id),
      // Server-side auth_sessions enforces inactivity and the 8-hour hard cap.
      expiresIn: process.env.ACCESS_TOKEN_TTL || '8h',
      issuer: 'muretake-api',
      audience: 'muretake-app',
    },
  );
}

function createRefreshToken() {
  return crypto.randomBytes(64).toString('base64url');
}

function createSessionId() {
  return crypto.randomBytes(32).toString('hex');
}

function hashRefreshToken(refreshToken) {
  return crypto
    .createHash('sha256')
    .update(refreshToken)
    .digest('hex');
}

module.exports = {
  createAccessToken,
  createRefreshToken,
  createSessionId,
  hashRefreshToken,
};

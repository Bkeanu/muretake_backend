const express = require('express');
const helmet = require('helmet');
const cors = require('cors');

require('dotenv').config();

const pool = require('./db');
const authRoutes = require('./routes/auth.routes');
const adminRoutes = require('./routes/admin.routes');
const contractRoutes = require('./routes/contracts.routes');

const app = express();

const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet());
app.use(cors());

// Allow JSON request bodies
app.use(express.json());

// ================================
// API ROUTES
// ================================

// Authentication routes
app.use('/api/auth', authRoutes);

// Admin routes
app.use('/api/admin', adminRoutes);

// Contract routes
app.use('/api/contracts', contractRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    message: 'Muretake API is running',
  });
});

// Database health check
app.get('/api/db-health', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT NOW() AS database_time',
    );

    res.status(200).json({
      status: 'ok',
      message: 'Neon PostgreSQL connected',
      databaseTime: result.rows[0].database_time,
    });
  } catch (error) {
    console.error('Database connection error:', error);

    res.status(500).json({
      status: 'error',
      message: 'Database connection failed',
    });
  }
});

// ================================
// START SERVER
// ================================

app.listen(PORT, '0.0.0.0', () => {
  console.log(
    `Muretake API running on http://localhost:${PORT}`,
  );
});

-- Run once. Copies the actual ID types from existing tables without copying data.
-- The migration runner wraps this entire file in a transaction.
CREATE TABLE daily_reports AS
SELECT b.id AS branch_id, u.id AS officer_id
FROM branches b CROSS JOIN users u
WITH NO DATA;

ALTER TABLE daily_reports
  ADD COLUMN id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  ADD COLUMN branch_name text NOT NULL,
  ADD COLUMN officer_name text NOT NULL,
  ADD COLUMN report_date date NOT NULL,
  ADD COLUMN submitted_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD COLUMN report_values jsonb NOT NULL CHECK (jsonb_typeof(report_values) = 'object'),
  ALTER COLUMN branch_id SET NOT NULL,
  ALTER COLUMN officer_id SET NOT NULL,
  ADD CONSTRAINT daily_reports_branch_fk FOREIGN KEY (branch_id) REFERENCES branches(id),
  ADD CONSTRAINT daily_reports_officer_fk FOREIGN KEY (officer_id) REFERENCES users(id),
  ADD CONSTRAINT daily_reports_branch_day UNIQUE (branch_id, report_date);

CREATE INDEX daily_reports_date_idx ON daily_reports(report_date);

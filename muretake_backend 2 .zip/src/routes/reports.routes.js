const express = require('express');

const {
  sensitiveActionLimiter,
} = require('../middleware/rateLimit.middleware');

const { requireAuth } = require('../middleware/auth.middleware');
const {
  getDailyReportSummary,
  submitDailyReport,
  listDailyReports,
} = require('../controllers/reports.controller');

const router = express.Router();

router.get('/summary', requireAuth, getDailyReportSummary);
router.get('/', requireAuth, listDailyReports);
router.post('/', requireAuth, sensitiveActionLimiter, submitDailyReport);

module.exports = router;

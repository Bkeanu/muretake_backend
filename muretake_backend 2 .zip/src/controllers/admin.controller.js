const pool = require('../db');
const { hashPassword } = require('../services/password.service');

function isValidTemporaryPassword(password) {
  if (password.length < 10 || password.length > 128) return false;

  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasDigit = /[0-9]/.test(password);

  return hasUppercase && hasLowercase && hasDigit;
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}


async function listOfficers(req, res) {
  // Authentication middleware has already verified the access token.
  // Only admins are allowed to view all Mweka Hazina accounts.
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  try {
    const result = await pool.query(
      `
      SELECT
        u.id,
        u.full_name,
        u.username,
        u.role,
        u.branch_id,
        b.name AS branch_name,
        u.is_active,
        u.must_change_password,
        u.created_at
      FROM users AS u
      INNER JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.role = 'officer'
      ORDER BY u.created_at DESC, u.id DESC
      `,
    );

    return res.status(200).json({
      success: true,
      officers: result.rows.map((officer) => ({
        id: officer.id,
        fullName: officer.full_name,
        username: officer.username,
        role: officer.role,
        branchId: officer.branch_id,
        branchName: officer.branch_name,
        isActive: officer.is_active,
        mustChangePassword: officer.must_change_password,
        createdAt: officer.created_at,
      })),
    });
  } catch (error) {
    console.error('List officers error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}

async function createOfficer(req, res) {
  // Authentication middleware has already verified the access token.
  // Only admins are allowed to create Mweka Hazina accounts.
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const fullName =
    typeof req.body.fullName === 'string'
      ? req.body.fullName.trim()
      : '';

  const username =
    typeof req.body.username === 'string'
      ? req.body.username.trim()
      : '';

  // Do not trim the password. A password is treated as the exact secret
  // entered by the admin.
  const password =
    typeof req.body.password === 'string'
      ? req.body.password
      : '';

  const branchId = Number(req.body.branchId);

  if (!fullName || !username || !password || !Number.isInteger(branchId)) {
    return res.status(400).json({
      success: false,
      message: 'Full name, username, password and branch are required.',
    });
  }

  if (fullName.length > 120) {
    return res.status(400).json({
      success: false,
      message: 'Full name is too long.',
    });
  }

  if (username.length < 3 || username.length > 50 || /\s/.test(username)) {
    return res.status(400).json({
      success: false,
      message: 'Username must be 3-50 characters and cannot contain spaces.',
    });
  }

  if (!isValidTemporaryPassword(password)) {
    return res.status(400).json({
      success: false,
      message:
        'Temporary password must be 10-128 characters and contain uppercase, lowercase and a number.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // Make sure the selected branch really exists in the database and is active.
    // Parameterized SQL prevents user input from becoming executable SQL.
    const branchResult = await client.query(
      `
      SELECT id, name
      FROM branches
      WHERE id = $1
        AND is_active = TRUE
      LIMIT 1
      `,
      [branchId],
    );

    if (branchResult.rows.length === 0) {
      await client.query('ROLLBACK');

      return res.status(400).json({
        success: false,
        message: 'Selected branch does not exist or is inactive.',
      });
    }

    // Login is case-insensitive, so creation must also reject usernames that
    // differ only by letter case.
    const existingUsername = await client.query(
      `
      SELECT id
      FROM users
      WHERE LOWER(username) = LOWER($1)
      LIMIT 1
      `,
      [username],
    );

    if (existingUsername.rows.length > 0) {
      await client.query('ROLLBACK');

      return res.status(409).json({
        success: false,
        message: 'That username is already in use.',
      });
    }

    // Password hashing happens only on the server. Plaintext is never stored.
    const passwordHash = await hashPassword(password);

    const insertResult = await client.query(
      `
      INSERT INTO users (
        full_name,
        username,
        password_hash,
        role,
        branch_id,
        is_active,
        must_change_password,
        failed_attempts,
        locked_until
      )
      VALUES (
        $1,
        $2,
        $3,
        'officer',
        $4,
        TRUE,
        TRUE,
        0,
        NULL
      )
      RETURNING
        id,
        full_name,
        username,
        role,
        branch_id,
        is_active,
        must_change_password,
        created_at
      `,
      [fullName, username, passwordHash, branchId],
    );

    await client.query('COMMIT');

    const officer = insertResult.rows[0];
    const branch = branchResult.rows[0];

    // Never return password or password_hash.
    return res.status(201).json({
      success: true,
      message: 'Loan officer created successfully.',
      officer: {
        id: officer.id,
        fullName: officer.full_name,
        username: officer.username,
        role: officer.role,
        branchId: officer.branch_id,
        branchName: branch.name,
        isActive: officer.is_active,
        mustChangePassword: officer.must_change_password,
        createdAt: officer.created_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    // PostgreSQL unique_violation. Keep this as a safe client-facing message.
    if (error && error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'That username is already in use.',
      });
    }

    console.error('Create officer error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}

async function setOfficerStatus(req, res) {
  // Authentication middleware has already verified the access token.
  // Only admins may enable or disable Mweka Hazina accounts.
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const officerId = Number(req.params.officerId);
  const isActive = req.body.isActive;

  if (!Number.isInteger(officerId) || officerId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid officer ID.',
    });
  }

  if (typeof isActive !== 'boolean') {
    return res.status(400).json({
      success: false,
      message: 'isActive must be true or false.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // Lock the target officer row while changing account status.
    const officerResult = await client.query(
      `
      SELECT
        u.id,
        u.full_name,
        u.username,
        u.role,
        u.branch_id,
        u.is_active,
        b.name AS branch_name,
        b.is_active AS branch_is_active
      FROM users AS u
      INNER JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
        AND u.role = 'officer'
      FOR UPDATE OF u
      `,
      [officerId],
    );

    if (officerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Mweka Hazina account was not found.',
      });
    }

    const existingOfficer = officerResult.rows[0];

    // Do not activate an officer whose assigned branch has been disabled.
    if (isActive && !existingOfficer.branch_is_active) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'The assigned branch is inactive.',
      });
    }

    const updateResult = await client.query(
      `
      UPDATE users
      SET
        is_active = $1,
        failed_attempts = CASE WHEN $1 = TRUE THEN 0 ELSE failed_attempts END,
        locked_until = CASE WHEN $1 = TRUE THEN NULL ELSE locked_until END,
        updated_at = NOW()
      WHERE id = $2
        AND role = 'officer'
      RETURNING
        id,
        full_name,
        username,
        role,
        branch_id,
        is_active,
        must_change_password,
        updated_at
      `,
      [isActive, officerId],
    );

    // Disabling also revokes refresh sessions. requireAuth checks is_active
    // on every protected request, so existing access tokens stop working too.
    if (!isActive) {
      await client.query(
        `
        DELETE FROM auth_sessions
        WHERE user_id = $1
        `,
        [officerId],
      );
    }

    await client.query('COMMIT');

    const officer = updateResult.rows[0];

    return res.status(200).json({
      success: true,
      message: isActive
        ? 'Loan officer enabled successfully.'
        : 'Loan officer disabled successfully.',
      officer: {
        id: officer.id,
        fullName: officer.full_name,
        username: officer.username,
        role: officer.role,
        branchId: officer.branch_id,
        branchName: existingOfficer.branch_name,
        isActive: officer.is_active,
        mustChangePassword: officer.must_change_password,
        updatedAt: officer.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Set officer status error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}


async function updateOfficer(req, res) {
  // Only admins may edit Mweka Hazina account details.
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const officerId = Number(req.params.officerId);
  const fullName =
    typeof req.body.fullName === 'string'
      ? req.body.fullName.trim()
      : '';
  const username =
    typeof req.body.username === 'string'
      ? req.body.username.trim()
      : '';
  const branchId = Number(req.body.branchId);

  if (!Number.isInteger(officerId) || officerId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid officer ID.',
    });
  }

  if (!fullName || !username || !Number.isInteger(branchId)) {
    return res.status(400).json({
      success: false,
      message: 'Full name, username and branch are required.',
    });
  }

  if (fullName.length > 120) {
    return res.status(400).json({
      success: false,
      message: 'Full name is too long.',
    });
  }

  if (username.length < 3 || username.length > 50 || /\s/.test(username)) {
    return res.status(400).json({
      success: false,
      message: 'Username must be 3-50 characters and cannot contain spaces.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const officerResult = await client.query(
      `
      SELECT
        id,
        full_name,
        username,
        branch_id,
        is_active,
        must_change_password
      FROM users
      WHERE id = $1
        AND role = 'officer'
      FOR UPDATE
      `,
      [officerId],
    );

    if (officerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Mweka Hazina account was not found.',
      });
    }

    const branchResult = await client.query(
      `
      SELECT id, name
      FROM branches
      WHERE id = $1
        AND is_active = TRUE
      LIMIT 1
      `,
      [branchId],
    );

    if (branchResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        success: false,
        message: 'Selected branch does not exist or is inactive.',
      });
    }

    const usernameResult = await client.query(
      `
      SELECT id
      FROM users
      WHERE LOWER(username) = LOWER($1)
        AND id <> $2
      LIMIT 1
      `,
      [username, officerId],
    );

    if (usernameResult.rows.length > 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'That username is already in use.',
      });
    }

    const updateResult = await client.query(
      `
      UPDATE users
      SET
        full_name = $1,
        username = $2,
        branch_id = $3,
        updated_at = NOW()
      WHERE id = $4
        AND role = 'officer'
      RETURNING
        id,
        full_name,
        username,
        role,
        branch_id,
        is_active,
        must_change_password,
        updated_at
      `,
      [fullName, username, branchId, officerId],
    );

    await client.query('COMMIT');

    const officer = updateResult.rows[0];

    return res.status(200).json({
      success: true,
      message: 'Loan officer updated successfully.',
      officer: {
        id: officer.id,
        fullName: officer.full_name,
        username: officer.username,
        role: officer.role,
        branchId: officer.branch_id,
        branchName: branchResult.rows[0].name,
        isActive: officer.is_active,
        mustChangePassword: officer.must_change_password,
        updatedAt: officer.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    if (error && error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'That username is already in use.',
      });
    }

    console.error('Update officer error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}

async function resetOfficerPassword(req, res) {
  // Authentication middleware has already verified the access token.
  // Only admins may issue a new temporary password to Mweka Hazina accounts.
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const officerId = Number(req.params.officerId);

  // Do not trim passwords. The exact secret entered by the admin is hashed.
  const temporaryPassword =
    typeof req.body.temporaryPassword === 'string'
      ? req.body.temporaryPassword
      : '';

  if (!Number.isInteger(officerId) || officerId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid officer ID.',
    });
  }

  if (!isValidTemporaryPassword(temporaryPassword)) {
    return res.status(400).json({
      success: false,
      message:
        'Temporary password must be 10-128 characters and contain uppercase, lowercase and a number.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // Lock the officer row so the reset is atomic with session revocation.
    const officerResult = await client.query(
      `
      SELECT
        u.id,
        u.full_name,
        u.username,
        u.role,
        u.branch_id,
        u.is_active,
        b.name AS branch_name
      FROM users AS u
      INNER JOIN branches AS b
        ON b.id = u.branch_id
      WHERE u.id = $1
        AND u.role = 'officer'
      FOR UPDATE OF u
      `,
      [officerId],
    );

    if (officerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Mweka Hazina account was not found.',
      });
    }

    const passwordHash = await hashPassword(temporaryPassword);

    const updateResult = await client.query(
      `
      UPDATE users
      SET
        password_hash = $1,
        must_change_password = TRUE,
        failed_attempts = 0,
        locked_until = NULL,
        password_changed_at = NOW(),
        updated_at = NOW()
      WHERE id = $2
        AND role = 'officer'
      RETURNING
        id,
        full_name,
        username,
        role,
        branch_id,
        is_active,
        must_change_password,
        updated_at
      `,
      [passwordHash, officerId],
    );

    // A password reset invalidates every existing refresh session.
    // Existing protected access tokens are also rejected by the middleware
    // after session/user checks as designed in the authentication layer.
    await client.query(
      `
      DELETE FROM auth_sessions
      WHERE user_id = $1
      `,
      [officerId],
    );

    await client.query('COMMIT');

    const officer = updateResult.rows[0];
    const existingOfficer = officerResult.rows[0];

    // Never return the plaintext password or password_hash.
    return res.status(200).json({
      success: true,
      message: 'Loan officer password reset successfully.',
      officer: {
        id: officer.id,
        fullName: officer.full_name,
        username: officer.username,
        role: officer.role,
        branchId: officer.branch_id,
        branchName: existingOfficer.branch_name,
        isActive: officer.is_active,
        mustChangePassword: officer.must_change_password,
        updatedAt: officer.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Reset officer password error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}


async function listBranches(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  try {
    const result = await pool.query(
      `
      SELECT
        b.id,
        b.name,
        b.opening_balance,
        b.current_balance,
        b.is_active,
        b.created_at,
        b.updated_at,
        COUNT(u.id) FILTER (WHERE u.role = 'officer')::int AS officer_count
      FROM branches AS b
      LEFT JOIN users AS u
        ON u.branch_id = b.id
      GROUP BY
        b.id,
        b.name,
        b.opening_balance,
        b.current_balance,
        b.is_active,
        b.created_at,
        b.updated_at
      ORDER BY b.id ASC
      `,
    );

    return res.status(200).json({
      success: true,
      branches: result.rows.map((branch) => ({
        id: branch.id,
        name: branch.name,
        openingBalance: Number(branch.opening_balance),
        currentBalance: Number(branch.current_balance),
        isActive: branch.is_active,
        officerCount: Number(branch.officer_count || 0),
        createdAt: branch.created_at,
        updatedAt: branch.updated_at,
      })),
    });
  } catch (error) {
    console.error('List branches error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}

async function createBranch(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const name =
    typeof req.body.name === 'string'
      ? req.body.name.trim()
      : '';

  const openingBalance = Number(req.body.openingBalance);

  if (!name || !Number.isFinite(openingBalance)) {
    return res.status(400).json({
      success: false,
      message: 'Branch name and opening balance are required.',
    });
  }

  if (name.length > 120) {
    return res.status(400).json({
      success: false,
      message: 'Branch name is too long.',
    });
  }

  if (openingBalance < 0) {
    return res.status(400).json({
      success: false,
      message: 'Opening balance cannot be negative.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const duplicate = await client.query(
      `
      SELECT id
      FROM branches
      WHERE LOWER(name) = LOWER($1)
      LIMIT 1
      `,
      [name],
    );

    if (duplicate.rows.length > 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'A branch with that name already exists.',
      });
    }

    const result = await client.query(
      `
      INSERT INTO branches (
        name,
        opening_balance,
        current_balance,
        is_active
      )
      VALUES ($1, $2, $2, TRUE)
      RETURNING
        id,
        name,
        opening_balance,
        current_balance,
        is_active,
        created_at,
        updated_at
      `,
      [name, openingBalance],
    );

    const branch = result.rows[0];

    await client.query(
      `
      INSERT INTO branch_balance_transactions (
        branch_id, transaction_type, amount, balance_before, balance_after,
        performed_by, reference_type, reference_id, reason
      )
      VALUES ($1, 'opening_snapshot', 0, $2, $2, $3, 'branch_creation', $1, 'Initial branch balance')
      `,
      [branch.id, Number(branch.current_balance), req.user.id],
    );

    await client.query('COMMIT');

    return res.status(201).json({
      success: true,
      message: 'Branch created successfully.',
      branch: {
        id: branch.id,
        name: branch.name,
        openingBalance: Number(branch.opening_balance),
        currentBalance: Number(branch.current_balance),
        isActive: branch.is_active,
        officerCount: 0,
        createdAt: branch.created_at,
        updatedAt: branch.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    if (error && error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'A branch with that name already exists.',
      });
    }

    console.error('Create branch error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}

async function updateBranch(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const branchId = Number(req.params.branchId);

  if (!Number.isInteger(branchId) || branchId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid branch ID.',
    });
  }

  // STEP 3 SECURITY RULE:
  // opening_balance is set exactly once when the branch is created.
  // current_balance may only move through approved balance transactions
  // (admin top-up, audited adjustment, or loan disbursement).
  // Never allow the generic branch-edit endpoint to overwrite either value.
  const protectedBalanceFields = [
    'openingBalance',
    'currentBalance',
    'opening_balance',
    'current_balance',
  ];

  const attemptedBalanceEdit = protectedBalanceFields.some((field) =>
    Object.prototype.hasOwnProperty.call(req.body || {}, field),
  );

  if (attemptedBalanceEdit) {
    return res.status(409).json({
      success: false,
      code: 'BRANCH_BALANCE_LOCKED',
      message:
        'Branch balances are locked. Use top-up or audited balance adjustment instead.',
    });
  }

  const hasName = Object.prototype.hasOwnProperty.call(req.body || {}, 'name');

  if (!hasName) {
    return res.status(400).json({
      success: false,
      message: 'No editable branch changes were provided.',
    });
  }

  const requestedName =
    typeof req.body.name === 'string' ? req.body.name.trim() : '';

  if (!requestedName || requestedName.length > 120) {
    return res.status(400).json({
      success: false,
      message: 'A valid branch name is required.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const existingResult = await client.query(
      `
      SELECT
        id,
        name,
        opening_balance,
        current_balance,
        is_active
      FROM branches
      WHERE id = $1
      FOR UPDATE
      `,
      [branchId],
    );

    if (existingResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Branch was not found.',
      });
    }

    const existing = existingResult.rows[0];

    if (requestedName.toLowerCase() !== existing.name.toLowerCase()) {
      const duplicate = await client.query(
        `
        SELECT id
        FROM branches
        WHERE LOWER(name) = LOWER($1)
          AND id <> $2
        LIMIT 1
        `,
        [requestedName, branchId],
      );

      if (duplicate.rows.length > 0) {
        await client.query('ROLLBACK');
        return res.status(409).json({
          success: false,
          message: 'A branch with that name already exists.',
        });
      }
    }

    const result = await client.query(
      `
      UPDATE branches
      SET
        name = $1,
        updated_at = NOW()
      WHERE id = $2
      RETURNING
        id,
        name,
        opening_balance,
        current_balance,
        is_active,
        created_at,
        updated_at
      `,
      [requestedName, branchId],
    );

    await client.query('COMMIT');

    const branch = result.rows[0];

    return res.status(200).json({
      success: true,
      message: 'Branch updated successfully.',
      branch: {
        id: branch.id,
        name: branch.name,
        openingBalance: Number(branch.opening_balance),
        currentBalance: Number(branch.current_balance),
        isActive: branch.is_active,
        createdAt: branch.created_at,
        updatedAt: branch.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    if (error && error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'A branch with that name already exists.',
      });
    }

    console.error('Update branch error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}

async function setBranchStatus(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const branchId = Number(req.params.branchId);
  const isActive = req.body.isActive;

  if (!Number.isInteger(branchId) || branchId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid branch ID.',
    });
  }

  if (typeof isActive !== 'boolean') {
    return res.status(400).json({
      success: false,
      message: 'isActive must be true or false.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const branchResult = await client.query(
      `
      SELECT id, name, is_active
      FROM branches
      WHERE id = $1
      FOR UPDATE
      `,
      [branchId],
    );

    if (branchResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Branch was not found.',
      });
    }

    // An inactive branch must not still contain an active officer account.
    // The admin can disable/reassign those officers first, then disable branch.
    if (!isActive) {
      const activeOfficers = await client.query(
        `
        SELECT COUNT(*)::int AS count
        FROM users
        WHERE role = 'officer'
          AND branch_id = $1
          AND is_active = TRUE
        `,
        [branchId],
      );

      if (Number(activeOfficers.rows[0].count) > 0) {
        await client.query('ROLLBACK');
        return res.status(409).json({
          success: false,
          message: 'Disable or move active officers before disabling this branch.',
        });
      }
    }

    const result = await client.query(
      `
      UPDATE branches
      SET
        is_active = $1,
        updated_at = NOW()
      WHERE id = $2
      RETURNING
        id,
        name,
        opening_balance,
        current_balance,
        is_active,
        created_at,
        updated_at
      `,
      [isActive, branchId],
    );

    await client.query('COMMIT');

    const branch = result.rows[0];

    return res.status(200).json({
      success: true,
      message: isActive
        ? 'Branch enabled successfully.'
        : 'Branch disabled successfully.',
      branch: {
        id: branch.id,
        name: branch.name,
        openingBalance: Number(branch.opening_balance),
        currentBalance: Number(branch.current_balance),
        isActive: branch.is_active,
        createdAt: branch.created_at,
        updatedAt: branch.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Set branch status error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}


async function listPendingContracts(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  try {
    const result = await pool.query(
      `
      SELECT
        c.id,
        c.borrower_name,
        c.phone_number,
        c.borrowed_amount,
        c.interest_rate,
        c.total_debt,
        c.remaining_debt,
        c.payment_interval,
        c.lifetime_value,
        c.status,
        c.officer_id,
        u.full_name AS officer_name,
        c.branch_id,
        b.name AS branch_name,
        c.submitted_at,
        c.created_at,
        c.updated_at
      FROM contracts AS c
      INNER JOIN users AS u
        ON u.id = c.officer_id
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      WHERE c.status = 'pending'
      ORDER BY c.submitted_at ASC, c.id ASC
      `,
    );

    return res.status(200).json({
      success: true,
      contracts: result.rows.map((contract) => ({
        id: contract.id,
        borrowerName: contract.borrower_name,
        phoneNumber: contract.phone_number,
        borrowedAmount: Number(contract.borrowed_amount),
        interestRate: Number(contract.interest_rate),
        totalDebt: Number(contract.total_debt),
        remainingDebt: Number(contract.remaining_debt),
        interval: contract.payment_interval,
        lifetimeValue: contract.lifetime_value,
        status: contract.status,
        officerId: contract.officer_id,
        officerName: contract.officer_name,
        branchId: contract.branch_id,
        branchName: contract.branch_name,
        submittedAt: contract.submitted_at,
        createdAt: contract.created_at,
        updatedAt: contract.updated_at,
      })),
    });
  } catch (error) {
    console.error('List pending contracts error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}

async function approveContract(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const contractId = Number(req.params.contractId);

  if (!Number.isInteger(contractId) || contractId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid contract ID.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const contractResult = await client.query(
      `
      SELECT
        c.id,
        c.borrower_name,
        c.phone_number,
        c.borrowed_amount,
        c.interest_rate,
        c.total_debt,
        c.remaining_debt,
        c.payment_interval,
        c.lifetime_value,
        c.status,
        c.officer_id,
        c.branch_id,
        c.submitted_at,
        u.full_name AS officer_name,
        u.is_active AS officer_is_active,
        b.name AS branch_name,
        b.is_active AS branch_is_active,
        b.current_balance
      FROM contracts AS c
      INNER JOIN users AS u
        ON u.id = c.officer_id
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      WHERE c.id = $1
      FOR UPDATE OF c, b
      `,
      [contractId],
    );

    if (contractResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Contract was not found.',
      });
    }

    const existing = contractResult.rows[0];

    if (existing.status !== 'pending') {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Only a pending contract can be approved.',
      });
    }

    if (!existing.officer_is_active) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'The loan officer account is inactive.',
      });
    }

    if (!existing.branch_is_active) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'The contract branch is inactive.',
      });
    }

    const borrowedAmount = Number(existing.borrowed_amount);
    const currentBalance = Number(existing.current_balance);

    if (currentBalance < borrowedAmount) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Branch balance is not enough to approve this contract.',
      });
    }

    const updateResult = await client.query(
      `
      UPDATE contracts
      SET
        status = 'active',
        contract_start_date = NOW(),
        approved_at = NOW(),
        approved_by = $1,
        updated_at = NOW()
      WHERE id = $2
        AND status = 'pending'
      RETURNING
        id,
        borrower_name,
        phone_number,
        borrowed_amount,
        interest_rate,
        total_debt,
        remaining_debt,
        payment_interval,
        lifetime_value,
        status,
        officer_id,
        branch_id,
        submitted_at,
        contract_start_date,
        approved_at,
        approved_by,
        created_at,
        updated_at
      `,
      [req.user.id, contractId],
    );

    if (updateResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Contract status changed before approval completed.',
      });
    }

    const branchResult = await client.query(
      `
      UPDATE branches
      SET
        current_balance = current_balance - $1,
        updated_at = NOW()
      WHERE id = $2
      RETURNING current_balance
      `,
      [borrowedAmount, existing.branch_id],
    );

    const balanceAfter = Number(branchResult.rows[0].current_balance);

    await client.query(
      `
      INSERT INTO branch_balance_transactions (
        branch_id, transaction_type, amount, balance_before, balance_after,
        performed_by, reference_type, reference_id, reason
      )
      VALUES ($1, 'loan_disbursement', $2, $3, $4, $5, 'contract', $6,
              'Loan principal disbursed on contract approval')
      `,
      [existing.branch_id, borrowedAmount, currentBalance, balanceAfter, req.user.id, contractId],
    );

    await client.query('COMMIT');

    const contract = updateResult.rows[0];

    return res.status(200).json({
      success: true,
      message: 'Contract approved successfully.',
      contract: {
        id: contract.id,
        borrowerName: contract.borrower_name,
        phoneNumber: contract.phone_number,
        borrowedAmount: Number(contract.borrowed_amount),
        interestRate: Number(contract.interest_rate),
        totalDebt: Number(contract.total_debt),
        remainingDebt: Number(contract.remaining_debt),
        interval: contract.payment_interval,
        lifetimeValue: contract.lifetime_value,
        status: contract.status,
        officerId: contract.officer_id,
        officerName: existing.officer_name,
        branchId: contract.branch_id,
        branchName: existing.branch_name,
        submittedAt: contract.submitted_at,
        contractStartDate: contract.contract_start_date,
        approvedAt: contract.approved_at,
        approvedBy: contract.approved_by,
        branchCurrentBalance: Number(branchResult.rows[0].current_balance),
        createdAt: contract.created_at,
        updatedAt: contract.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Approve contract error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}

async function rejectContract(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const contractId = Number(req.params.contractId);
  const rejectionReason =
    typeof req.body.rejectionReason === 'string'
      ? req.body.rejectionReason.trim()
      : '';

  if (!Number.isInteger(contractId) || contractId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Invalid contract ID.',
    });
  }

  if (rejectionReason.length > 500) {
    return res.status(400).json({
      success: false,
      message: 'Rejection reason is too long.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const existingResult = await client.query(
      `
      SELECT
        c.id,
        c.status,
        c.officer_id,
        c.branch_id,
        u.full_name AS officer_name,
        b.name AS branch_name
      FROM contracts AS c
      INNER JOIN users AS u
        ON u.id = c.officer_id
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      WHERE c.id = $1
      FOR UPDATE OF c
      `,
      [contractId],
    );

    if (existingResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({
        success: false,
        message: 'Contract was not found.',
      });
    }

    const existing = existingResult.rows[0];

    if (existing.status !== 'pending') {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Only a pending contract can be rejected.',
      });
    }

    const updateResult = await client.query(
      `
      UPDATE contracts
      SET
        status = 'rejected',
        rejected_at = NOW(),
        rejected_by = $1,
        rejection_reason = NULLIF($2, ''),
        updated_at = NOW()
      WHERE id = $3
        AND status = 'pending'
      RETURNING
        id,
        borrower_name,
        phone_number,
        borrowed_amount,
        interest_rate,
        total_debt,
        remaining_debt,
        payment_interval,
        lifetime_value,
        status,
        officer_id,
        branch_id,
        submitted_at,
        rejected_at,
        rejected_by,
        rejection_reason,
        created_at,
        updated_at
      `,
      [req.user.id, rejectionReason, contractId],
    );

    if (updateResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        success: false,
        message: 'Contract status changed before rejection completed.',
      });
    }

    await client.query('COMMIT');

    const contract = updateResult.rows[0];

    return res.status(200).json({
      success: true,
      message: 'Contract rejected successfully.',
      contract: {
        id: contract.id,
        borrowerName: contract.borrower_name,
        phoneNumber: contract.phone_number,
        borrowedAmount: Number(contract.borrowed_amount),
        interestRate: Number(contract.interest_rate),
        totalDebt: Number(contract.total_debt),
        remainingDebt: Number(contract.remaining_debt),
        interval: contract.payment_interval,
        lifetimeValue: contract.lifetime_value,
        status: contract.status,
        officerId: contract.officer_id,
        officerName: existing.officer_name,
        branchId: contract.branch_id,
        branchName: existing.branch_name,
        submittedAt: contract.submitted_at,
        rejectedAt: contract.rejected_at,
        rejectedBy: contract.rejected_by,
        rejectionReason: contract.rejection_reason,
        createdAt: contract.created_at,
        updatedAt: contract.updated_at,
      },
    });
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Reject contract error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  } finally {
    client.release();
  }
}



async function topUpBranchBalance(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin access is required.' });
  }
  const branchId = Number(req.params.branchId);
  const amount = roundMoney(req.body.amount);
  const reason = typeof req.body.reason === 'string' ? req.body.reason.trim() : '';
  if (!Number.isInteger(branchId) || branchId <= 0) {
    return res.status(400).json({ success: false, message: 'Invalid branch ID.' });
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    return res.status(400).json({ success: false, message: 'Amount must be greater than zero.' });
  }
  if (!reason || reason.length > 500) {
    return res.status(400).json({ success: false, message: 'A reason is required and must be 500 characters or less.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const branchResult = await client.query(`
      SELECT id, name, opening_balance, current_balance, is_active
      FROM branches WHERE id = $1 FOR UPDATE
    `, [branchId]);
    if (branchResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ success: false, message: 'Branch was not found.' });
    }
    const branch = branchResult.rows[0];
    const balanceBefore = Number(branch.current_balance);
    const balanceAfter = roundMoney(balanceBefore + amount);
    const updatedResult = await client.query(`
      UPDATE branches SET current_balance = $1, updated_at = NOW()
      WHERE id = $2
      RETURNING id, name, opening_balance, current_balance, is_active, updated_at
    `, [balanceAfter, branchId]);
    const ledgerResult = await client.query(`
      INSERT INTO branch_balance_transactions (
        branch_id, transaction_type, amount, balance_before, balance_after,
        performed_by, reference_type, reference_id, reason
      ) VALUES ($1, 'admin_topup', $2, $3, $4, $5, 'admin_topup', NULL, $6)
      RETURNING id, transaction_type, amount, balance_before, balance_after, reason, created_at
    `, [branchId, amount, balanceBefore, balanceAfter, req.user.id, reason]);
    await client.query('COMMIT');
    const updated = updatedResult.rows[0]; const ledger = ledgerResult.rows[0];
    return res.status(201).json({
      success: true,
      message: 'Branch balance added successfully.',
      branch: { id: updated.id, name: updated.name, openingBalance: Number(updated.opening_balance), currentBalance: Number(updated.current_balance), isActive: updated.is_active, updatedAt: updated.updated_at },
      transaction: { id: ledger.id, type: ledger.transaction_type, amount: Number(ledger.amount), balanceBefore: Number(ledger.balance_before), balanceAfter: Number(ledger.balance_after), reason: ledger.reason, performedBy: req.user.id, createdAt: ledger.created_at },
    });
  } catch (error) {
    try { await client.query('ROLLBACK'); } catch (_) {}
    console.error('Top up branch balance error:', error);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  } finally { client.release(); }
}

async function adjustBranchBalance(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin access is required.' });
  }
  const branchId = Number(req.params.branchId);
  const direction = typeof req.body.direction === 'string' ? req.body.direction.trim().toLowerCase() : '';
  const amount = roundMoney(req.body.amount);
  const reason = typeof req.body.reason === 'string' ? req.body.reason.trim() : '';
  if (!Number.isInteger(branchId) || branchId <= 0) {
    return res.status(400).json({ success: false, message: 'Invalid branch ID.' });
  }
  if (!['add', 'subtract'].includes(direction)) {
    return res.status(400).json({ success: false, message: 'Direction must be add or subtract.' });
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    return res.status(400).json({ success: false, message: 'Amount must be greater than zero.' });
  }
  if (!reason || reason.length > 500) {
    return res.status(400).json({ success: false, message: 'A reason is required and must be 500 characters or less.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const branchResult = await client.query(`
      SELECT id, name, opening_balance, current_balance, is_active
      FROM branches WHERE id = $1 FOR UPDATE
    `, [branchId]);
    if (branchResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ success: false, message: 'Branch was not found.' });
    }
    const branch = branchResult.rows[0];
    const balanceBefore = Number(branch.current_balance);
    const balanceAfter = direction === 'add' ? roundMoney(balanceBefore + amount) : roundMoney(balanceBefore - amount);
    if (balanceAfter < 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({ success: false, message: 'The correction would make the branch balance negative.', currentBalance: balanceBefore });
    }
    const transactionType = direction === 'add' ? 'adjustment_add' : 'adjustment_subtract';
    const updatedResult = await client.query(`
      UPDATE branches SET current_balance = $1, updated_at = NOW()
      WHERE id = $2
      RETURNING id, name, opening_balance, current_balance, is_active, updated_at
    `, [balanceAfter, branchId]);
    const ledgerResult = await client.query(`
      INSERT INTO branch_balance_transactions (
        branch_id, transaction_type, amount, balance_before, balance_after,
        performed_by, reference_type, reference_id, reason
      ) VALUES ($1, $2, $3, $4, $5, $6, 'audit_correction', NULL, $7)
      RETURNING id, transaction_type, amount, balance_before, balance_after, reason, created_at
    `, [branchId, transactionType, amount, balanceBefore, balanceAfter, req.user.id, reason]);
    await client.query('COMMIT');
    const updated = updatedResult.rows[0]; const ledger = ledgerResult.rows[0];
    return res.status(201).json({
      success: true,
      message: 'Branch balance correction saved successfully.',
      branch: { id: updated.id, name: updated.name, openingBalance: Number(updated.opening_balance), currentBalance: Number(updated.current_balance), isActive: updated.is_active, updatedAt: updated.updated_at },
      transaction: { id: ledger.id, type: ledger.transaction_type, amount: Number(ledger.amount), balanceBefore: Number(ledger.balance_before), balanceAfter: Number(ledger.balance_after), reason: ledger.reason, performedBy: req.user.id, createdAt: ledger.created_at },
    });
  } catch (error) {
    try { await client.query('ROLLBACK'); } catch (_) {}
    console.error('Adjust branch balance error:', error);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  } finally { client.release(); }
}

async function listBranchBalanceHistory(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin access is required.' });
  }
  const branchId = Number(req.params.branchId);
  if (!Number.isInteger(branchId) || branchId <= 0) {
    return res.status(400).json({ success: false, message: 'Invalid branch ID.' });
  }
  try {
    const branchResult = await pool.query(`
      SELECT id, name, opening_balance, current_balance, is_active
      FROM branches WHERE id = $1 LIMIT 1
    `, [branchId]);
    if (branchResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Branch was not found.' });
    }
    const result = await pool.query(`
      SELECT t.id, t.branch_id, t.transaction_type, t.amount, t.balance_before,
             t.balance_after, t.performed_by, u.full_name AS performed_by_name,
             t.reference_type, t.reference_id, t.reason, t.created_at
      FROM branch_balance_transactions AS t
      LEFT JOIN users AS u ON u.id = t.performed_by
      WHERE t.branch_id = $1
      ORDER BY t.created_at DESC, t.id DESC
    `, [branchId]);
    const branch = branchResult.rows[0];
    return res.status(200).json({
      success: true,
      branch: { id: branch.id, name: branch.name, openingBalance: Number(branch.opening_balance), currentBalance: Number(branch.current_balance), isActive: branch.is_active },
      transactions: result.rows.map((row) => ({ id: row.id, branchId: row.branch_id, type: row.transaction_type, amount: Number(row.amount), balanceBefore: Number(row.balance_before), balanceAfter: Number(row.balance_after), performedBy: row.performed_by, performedByName: row.performed_by_name, referenceType: row.reference_type, referenceId: row.reference_id, reason: row.reason, createdAt: row.created_at })),
    });
  } catch (error) {
    console.error('List branch balance history error:', error);
    return res.status(500).json({ success: false, message: 'Internal server error.' });
  }
}


function parseAdminIsoDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return null;
  }

  const [year, month, day] = value.split('-').map(Number);
  const d = new Date(Date.UTC(year, month - 1, day));

  if (
    d.getUTCFullYear() !== year ||
    d.getUTCMonth() !== month - 1 ||
    d.getUTCDate() !== day
  ) {
    return null;
  }

  return { value, year, month, day, utc: d };
}

function formatAdminUtcDate(date) {
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, '0');
  const day = String(date.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function addAdminUtcDays(dateString, days) {
  const parsed = parseAdminIsoDate(dateString);
  if (!parsed) return null;
  const d = new Date(parsed.utc.getTime());
  d.setUTCDate(d.getUTCDate() + days);
  return formatAdminUtcDate(d);
}

function addAdminUtcMonthsSameDay(dateString, months) {
  const parsed = parseAdminIsoDate(dateString);
  if (!parsed) return null;

  const targetMonthIndex = parsed.month - 1 + months;
  const targetYear = parsed.year + Math.floor(targetMonthIndex / 12);
  const normalizedMonth = ((targetMonthIndex % 12) + 12) % 12;
  const d = new Date(Date.UTC(targetYear, normalizedMonth, parsed.day));

  if (
    d.getUTCFullYear() !== targetYear ||
    d.getUTCMonth() !== normalizedMonth ||
    d.getUTCDate() !== parsed.day
  ) {
    return null;
  }

  return formatAdminUtcDate(d);
}

function buildAdminContractDueDates(interval, startDateLocal, lifetimeValue, throughDate) {
  const dates = [];
  if (!parseAdminIsoDate(startDateLocal) || !parseAdminIsoDate(throughDate)) {
    return dates;
  }

  for (let installment = 1; installment <= lifetimeValue; installment += 1) {
    let dueDate = null;

    if (interval === 'daily') {
      dueDate = addAdminUtcDays(startDateLocal, installment);
    } else if (interval === 'weekly') {
      dueDate = addAdminUtcDays(startDateLocal, installment * 7);
    } else if (interval === 'monthly') {
      dueDate = addAdminUtcMonthsSameDay(startDateLocal, installment);
    }

    if (!dueDate) continue;
    if (dueDate > throughDate) break;
    dates.push(dueDate);
  }

  return dates;
}

async function markAllExpiredContractsDefaulted() {
  await pool.query(
    `
    UPDATE contracts
    SET
      status = 'defaulted',
      updated_at = NOW()
    WHERE status = 'active'
      AND remaining_debt > 0
      AND contract_start_date IS NOT NULL
      AND (
        (
          payment_interval = 'daily'
          AND NOW() > contract_start_date + make_interval(days => lifetime_value)
        )
        OR
        (
          payment_interval = 'weekly'
          AND NOW() > contract_start_date + make_interval(days => lifetime_value * 7)
        )
        OR
        (
          payment_interval = 'monthly'
          AND NOW() > contract_start_date + make_interval(months => lifetime_value)
        )
      )
    `,
  );
}

async function generateAdminMissingPenaltiesForBranch(client, branchId, throughDate) {
  const contractResult = await client.query(
    `
    SELECT
      c.id,
      c.total_debt,
      c.payment_interval,
      c.lifetime_value,
      TO_CHAR(
        c.contract_start_date AT TIME ZONE 'Africa/Dar_es_Salaam',
        'YYYY-MM-DD'
      ) AS contract_start_date_local
    FROM contracts AS c
    WHERE c.branch_id = $1
      AND c.contract_start_date IS NOT NULL
      AND c.status IN ('active', 'completed', 'defaulted')
    ORDER BY c.id ASC
    `,
    [branchId],
  );

  if (contractResult.rows.length === 0) return 0;

  const contractIds = contractResult.rows.map((row) => row.id);
  const paymentsResult = await client.query(
    `
    SELECT
      p.contract_id,
      p.amount,
      TO_CHAR(
        p.paid_at AT TIME ZONE 'Africa/Dar_es_Salaam',
        'YYYY-MM-DD'
      ) AS paid_date_local
    FROM payments AS p
    WHERE p.contract_id = ANY($1::bigint[])
    ORDER BY p.contract_id ASC, p.paid_at ASC, p.id ASC
    `,
    [contractIds],
  );

  const paymentsByContract = new Map();
  for (const payment of paymentsResult.rows) {
    const key = String(payment.contract_id);
    if (!paymentsByContract.has(key)) paymentsByContract.set(key, []);
    paymentsByContract.get(key).push({
      date: payment.paid_date_local,
      amount: Number(payment.amount),
    });
  }

  let generatedCount = 0;

  for (const contract of contractResult.rows) {
    const totalDebt = Number(contract.total_debt);
    const lifetimeValue = Number(contract.lifetime_value);
    if (!Number.isFinite(totalDebt) || totalDebt <= 0) continue;
    if (!Number.isInteger(lifetimeValue) || lifetimeValue <= 0) continue;

    const dueDates = buildAdminContractDueDates(
      contract.payment_interval,
      contract.contract_start_date_local,
      lifetimeValue,
      throughDate,
    );

    const payments = paymentsByContract.get(String(contract.id)) || [];

    for (const dueDate of dueDates) {
      let paidBeforeDate = 0;
      let paymentOnDate = false;

      for (const payment of payments) {
        if (payment.date < dueDate) {
          paidBeforeDate += payment.amount;
        } else if (payment.date === dueDate) {
          paymentOnDate = true;
        }
      }

      if (paidBeforeDate >= totalDebt - 0.005 || paymentOnDate) continue;

      const inserted = await client.query(
        `
        INSERT INTO penalty_events (
          contract_id,
          branch_id,
          due_date,
          amount,
          status
        )
        VALUES ($1, $2, $3::date, 2000, 'open')
        ON CONFLICT (contract_id, due_date) DO NOTHING
        RETURNING id
        `,
        [contract.id, branchId, dueDate],
      );

      if (inserted.rows.length > 0) generatedCount += 1;
    }
  }

  return generatedCount;
}

async function getDashboardSummary(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  try {
    await markAllExpiredContractsDefaulted();

    const [summaryResult, branchResult, balanceResult, collectionResult, penaltyResult] =
      await Promise.all([
        pool.query(
          `
          SELECT
            COUNT(*)::int AS total_contracts,
            COUNT(*) FILTER (WHERE status = 'pending')::int AS pending_contracts,
            COUNT(*) FILTER (WHERE status = 'active')::int AS active_contracts,
            COUNT(*) FILTER (WHERE status = 'completed')::int AS completed_contracts,
            COUNT(*) FILTER (WHERE status = 'defaulted')::int AS defaulted_contracts,
            COUNT(*) FILTER (
              WHERE approved_at IS NOT NULL
                AND (approved_at AT TIME ZONE 'Africa/Dar_es_Salaam')::date =
                    (NOW() AT TIME ZONE 'Africa/Dar_es_Salaam')::date
            )::int AS approved_today
          FROM contracts
          `,
        ),
        pool.query(
          `
          SELECT
            b.id,
            b.name,
            COUNT(c.id)::int AS contract_count
          FROM branches AS b
          LEFT JOIN contracts AS c
            ON c.branch_id = b.id
          GROUP BY b.id, b.name
          ORDER BY b.id ASC
          `,
        ),
        pool.query(
          `
          SELECT COALESCE(SUM(current_balance), 0) AS total_closing_balance
          FROM branches
          `,
        ),
        pool.query(
          `
          WITH approved_debt AS (
            SELECT COALESCE(SUM(total_debt), 0)::numeric AS total_debt
            FROM contracts
            WHERE approved_at IS NOT NULL
              AND status IN ('active', 'completed', 'defaulted')
          ),
          collected AS (
            SELECT COALESCE(SUM(amount), 0)::numeric AS total_collected
            FROM payments
          )
          SELECT
            CASE
              WHEN approved_debt.total_debt <= 0 THEN 0
              ELSE LEAST(
                100,
                (collected.total_collected / approved_debt.total_debt) * 100
              )
            END AS collection_rate
          FROM approved_debt, collected
          `,
        ),
        pool.query(
          `
          SELECT COALESCE(SUM(amount_paid), 0) AS penalty_collected
          FROM penalty_settlements
          `,
        ),
      ]);

    const summary = summaryResult.rows[0] || {};

    return res.status(200).json({
      success: true,
      dashboard: {
        totalContracts: Number(summary.total_contracts || 0),
        pendingContracts: Number(summary.pending_contracts || 0),
        activeContracts: Number(summary.active_contracts || 0),
        completedContracts: Number(summary.completed_contracts || 0),
        defaultedContracts: Number(summary.defaulted_contracts || 0),
        approvedToday: Number(summary.approved_today || 0),
        totalClosingBalance: Number(
          balanceResult.rows[0]?.total_closing_balance || 0,
        ),
        // Portfolio collection progress = all Rejesho collected / total debt
        // of approved operational contracts, capped at 100%.
        collectionRate: Number(collectionResult.rows[0]?.collection_rate || 0),
        // Actual Faini cash received. Waived amounts are excluded.
        penaltyCollected: Number(penaltyResult.rows[0]?.penalty_collected || 0),
        branches: branchResult.rows.map((branch) => ({
          id: branch.id,
          name: branch.name,
          contractCount: Number(branch.contract_count || 0),
        })),
      },
    });
  } catch (error) {
    console.error('Dashboard summary error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}

async function getAdminOverview(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const requestedDate = typeof req.query.date === 'string'
    ? req.query.date.trim()
    : '';
  const branchIdRaw = req.query.branchId;
  const branchId = branchIdRaw == null || branchIdRaw === ''
    ? null
    : Number(branchIdRaw);

  if (requestedDate && !parseAdminIsoDate(requestedDate)) {
    return res.status(400).json({
      success: false,
      message: 'Date must use YYYY-MM-DD format.',
    });
  }

  if (branchId !== null && (!Number.isInteger(branchId) || branchId <= 0)) {
    return res.status(400).json({
      success: false,
      message: 'Invalid branch ID.',
    });
  }

  try {
    const todayResult = await pool.query(
      `SELECT TO_CHAR(NOW() AT TIME ZONE 'Africa/Dar_es_Salaam', 'YYYY-MM-DD') AS today_local`,
    );
    const selectedDate = requestedDate || todayResult.rows[0].today_local;

    let selectedBranch = null;
    if (branchId !== null) {
      const branchResult = await pool.query(
        `SELECT id, name FROM branches WHERE id = $1 LIMIT 1`,
        [branchId],
      );
      if (branchResult.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'Branch was not found.',
        });
      }
      selectedBranch = branchResult.rows[0];
    }

    const [collectionsResult, penaltiesResult, loansResult] = await Promise.all([
      pool.query(
        `
        SELECT COALESCE(SUM(p.amount), 0) AS total
        FROM payments AS p
        WHERE (p.paid_at AT TIME ZONE 'Africa/Dar_es_Salaam')::date = $1::date
          AND ($2::bigint IS NULL OR p.branch_id = $2)
        `,
        [selectedDate, branchId],
      ),
      pool.query(
        `
        SELECT COALESCE(SUM(ps.amount_paid), 0) AS total
        FROM penalty_settlements AS ps
        WHERE (ps.settled_at AT TIME ZONE 'Africa/Dar_es_Salaam')::date = $1::date
          AND ($2::bigint IS NULL OR ps.branch_id = $2)
        `,
        [selectedDate, branchId],
      ),
      pool.query(
        `
        SELECT COALESCE(SUM(c.borrowed_amount), 0) AS total
        FROM contracts AS c
        WHERE c.approved_at IS NOT NULL
          AND (c.approved_at AT TIME ZONE 'Africa/Dar_es_Salaam')::date = $1::date
          AND ($2::bigint IS NULL OR c.branch_id = $2)
        `,
        [selectedDate, branchId],
      ),
    ]);

    return res.status(200).json({
      success: true,
      overview: {
        date: selectedDate,
        branchId: selectedBranch ? Number(selectedBranch.id) : null,
        branchName: selectedBranch ? selectedBranch.name : 'All Branches',
        collections: Number(collectionsResult.rows[0]?.total || 0),
        penaltyCollected: Number(penaltiesResult.rows[0]?.total || 0),
        loansGiven: Number(loansResult.rows[0]?.total || 0),
      },
    });
  } catch (error) {
    console.error('Admin overview error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}

async function listAdminContracts(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const view = typeof req.query.view === 'string'
    ? req.query.view.trim().toLowerCase()
    : 'all';
  const allowedViews = new Set(['all', 'approved', 'rejected', 'defaulted']);
  const branchIdRaw = req.query.branchId;
  const branchId = branchIdRaw == null || branchIdRaw === ''
    ? null
    : Number(branchIdRaw);

  if (!allowedViews.has(view)) {
    return res.status(400).json({
      success: false,
      message: 'Invalid contract view.',
    });
  }

  if (branchId !== null && (!Number.isInteger(branchId) || branchId <= 0)) {
    return res.status(400).json({
      success: false,
      message: 'Invalid branch ID.',
    });
  }

  try {
    await markAllExpiredContractsDefaulted();

    const result = await pool.query(
      `
      SELECT
        c.id,
        c.borrower_name,
        c.phone_number,
        c.borrowed_amount,
        c.total_debt,
        c.remaining_debt,
        c.payment_interval,
        c.lifetime_value,
        c.status,
        c.officer_id,
        officer.full_name AS officer_name,
        c.branch_id,
        b.name AS branch_name,
        c.submitted_at,
        c.contract_start_date,
        c.approved_at,
        c.rejected_at,
        c.rejection_reason,
        approved_admin.full_name AS approved_by_name,
        rejected_admin.full_name AS rejected_by_name
      FROM contracts AS c
      INNER JOIN users AS officer
        ON officer.id = c.officer_id
      INNER JOIN branches AS b
        ON b.id = c.branch_id
      LEFT JOIN users AS approved_admin
        ON approved_admin.id = c.approved_by
      LEFT JOIN users AS rejected_admin
        ON rejected_admin.id = c.rejected_by
      WHERE ($1::bigint IS NULL OR c.branch_id = $1)
        AND (
          $2 = 'all'
          OR ($2 = 'approved' AND c.approved_at IS NOT NULL AND c.status <> 'rejected')
          OR ($2 = 'rejected' AND c.status = 'rejected')
          OR ($2 = 'defaulted' AND c.status = 'defaulted')
        )
      ORDER BY
        b.id ASC,
        COALESCE(c.approved_at, c.rejected_at, c.submitted_at, c.created_at) DESC,
        c.id DESC
      `,
      [branchId, view],
    );

    return res.status(200).json({
      success: true,
      view,
      count: result.rows.length,
      contracts: result.rows.map((row) => ({
        id: row.id,
        borrowerName: row.borrower_name,
        phoneNumber: row.phone_number,
        borrowedAmount: Number(row.borrowed_amount),
        totalDebt: Number(row.total_debt),
        remainingDebt: Number(row.remaining_debt),
        interval: row.payment_interval,
        lifetimeValue: Number(row.lifetime_value),
        status: row.status,
        officerId: row.officer_id,
        officerName: row.officer_name,
        branchId: Number(row.branch_id),
        branchName: row.branch_name,
        submittedAt: row.submitted_at,
        contractStartDate: row.contract_start_date,
        approvedAt: row.approved_at,
        rejectedAt: row.rejected_at,
        rejectionReason: row.rejection_reason,
        approvedByName: row.approved_by_name,
        rejectedByName: row.rejected_by_name,
      })),
    });
  } catch (error) {
    console.error('List admin contracts error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}

async function listAdminPenalties(req, res) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Admin access is required.',
    });
  }

  const branchIdRaw = req.query.branchId;
  const branchId = branchIdRaw == null || branchIdRaw === ''
    ? null
    : Number(branchIdRaw);

  if (branchId !== null && (!Number.isInteger(branchId) || branchId <= 0)) {
    return res.status(400).json({
      success: false,
      message: 'Invalid branch ID.',
    });
  }

  try {
    // Admin Penalty is an audit view of money that has ALREADY been collected.
    // One row = one settlement action made by the officer who received the money.
    //
    // Keep the existing JSON field names used by Flutter so the current card
    // design does not need to change:
    //   totalPenaltyAmount -> actual amount_paid
    //   officerName        -> collector/recorded_by officer name
    const result = await pool.query(
      `
      SELECT
        ps.id AS settlement_id,
        ps.contract_id,
        c.borrower_name,
        c.phone_number,
        ps.branch_id,
        b.name AS branch_name,
        ps.total_penalty_amount AS original_penalty_amount,
        ps.amount_paid,
        ps.amount_waived,
        ps.recorded_by AS collector_id,
        collector.full_name AS collector_name,
        ps.note,
        ps.settled_at,
        COUNT(pe.id)::int AS settled_event_count
      FROM penalty_settlements AS ps
      INNER JOIN contracts AS c
        ON c.id = ps.contract_id
      INNER JOIN branches AS b
        ON b.id = ps.branch_id
      INNER JOIN users AS collector
        ON collector.id = ps.recorded_by
      LEFT JOIN penalty_events AS pe
        ON pe.settlement_id = ps.id
      WHERE ($1::bigint IS NULL OR ps.branch_id = $1)
      GROUP BY
        ps.id,
        ps.contract_id,
        c.borrower_name,
        c.phone_number,
        ps.branch_id,
        b.name,
        ps.total_penalty_amount,
        ps.amount_paid,
        ps.amount_waived,
        ps.recorded_by,
        collector.full_name,
        ps.note,
        ps.settled_at
      ORDER BY ps.settled_at DESC, ps.id DESC
      `,
      [branchId],
    );

    return res.status(200).json({
      success: true,
      count: result.rows.length,
      penalties: result.rows.map((row) => ({
        // Existing fields expected by the current Flutter Admin Penalty card.
        contractId: row.contract_id,
        borrowerName: row.borrower_name,
        phoneNumber: row.phone_number,
        officerId: row.collector_id,
        officerName: row.collector_name,
        branchId: Number(row.branch_id),
        branchName: row.branch_name,
        missedPaymentCount: Number(row.settled_event_count || 0),

        // IMPORTANT: Admin card now shows money ACTUALLY collected,
        // not the original/open penalty amount.
        totalPenaltyAmount: Number(row.amount_paid || 0),

        // Extra audit fields are included for future UI/reporting.
        settlementId: row.settlement_id,
        originalPenaltyAmount: Number(row.original_penalty_amount || 0),
        amountPaid: Number(row.amount_paid || 0),
        amountWaived: Number(row.amount_waived || 0),
        collectedById: row.collector_id,
        collectedByName: row.collector_name,
        note: row.note,
        settledAt: row.settled_at,
        status: 'settled',
      })),
    });
  } catch (error) {
    console.error('List admin collected penalties error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });
  }
}

module.exports = {
  getDashboardSummary,
  getAdminOverview,
  listAdminContracts,
  listAdminPenalties,
  createOfficer,
  listOfficers,
  setOfficerStatus,
  updateOfficer,
  resetOfficerPassword,
  listBranches,
  createBranch,
  updateBranch,
  setBranchStatus,
  topUpBranchBalance,
  adjustBranchBalance,
  listBranchBalanceHistory,
  listPendingContracts,
  approveContract,
  rejectContract,
};

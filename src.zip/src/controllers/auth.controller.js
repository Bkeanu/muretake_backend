const pool = require('../db');

const {
  verifyPassword,
} = require('../services/password.service');

const {
  createAccessToken,
  createRefreshToken,
  hashRefreshToken,
} = require('../services/token.service');


async function login(req, res) {
  const username =
      typeof req.body.username === 'string'
          ? req.body.username.trim()
          : '';

  const password =
      typeof req.body.password === 'string'
          ? req.body.password
          : '';

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: 'Username and password are required.',
    });
  }

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // PARAMETERIZED QUERY.
    // User input is never concatenated into SQL.
    const result = await client.query(
      `
      SELECT
        id,
        full_name,
        username,
        password_hash,
        role,
        branch_id,
        is_active,
        must_change_password,
        failed_attempts,
        locked_until
      FROM users
      WHERE LOWER(username) = LOWER($1)
      LIMIT 1
      FOR UPDATE
      `,
      [username],
    );

    // Generic response so we don't reveal whether
    // a username exists.
    if (result.rows.length === 0) {
      await client.query('COMMIT');

      return res.status(401).json({
        success: false,
        message: 'Username or password is incorrect.',
      });
    }

    const user = result.rows[0];

    if (!user.is_active) {
      await client.query('COMMIT');

      return res.status(403).json({
        success: false,
        message: 'This account is disabled.',
      });
    }

    const now = new Date();

    // Check existing lockout.
    if (
      user.locked_until &&
      new Date(user.locked_until) > now
    ) {
      await client.query('COMMIT');

      return res.status(423).json({
        success: false,
        message: 'Account is temporarily locked.',
        lockedUntil: user.locked_until,
      });
    }

    // If an old lock has already expired, clear it.
    if (
      user.locked_until &&
      new Date(user.locked_until) <= now
    ) {
      await client.query(
        `
        UPDATE users
        SET
          failed_attempts = 0,
          locked_until = NULL,
          updated_at = NOW()
        WHERE id = $1
        `,
        [user.id],
      );

      user.failed_attempts = 0;
      user.locked_until = null;
    }

    // Argon2id verification.
    const passwordCorrect = await verifyPassword(
      user.password_hash,
      password,
    );

    if (!passwordCorrect) {
      const newFailedAttempts =
          Number(user.failed_attempts || 0) + 1;

      // 3 incorrect attempts triggers lockout.
      if (newFailedAttempts >= 3) {
        const lockHours =
            user.role === 'admin' ? 5 : 3;

        const lockedUntil =
            new Date(
              Date.now() +
              lockHours * 60 * 60 * 1000,
            );

        await client.query(
          `
          UPDATE users
          SET
            failed_attempts = 0,
            locked_until = $1,
            updated_at = NOW()
          WHERE id = $2
          `,
          [
            lockedUntil,
            user.id,
          ],
        );

        await client.query('COMMIT');

        return res.status(423).json({
          success: false,
          message:
              'Too many failed login attempts. Account locked temporarily.',
          lockedUntil,
        });
      }

      await client.query(
        `
        UPDATE users
        SET
          failed_attempts = $1,
          updated_at = NOW()
        WHERE id = $2
        `,
        [
          newFailedAttempts,
          user.id,
        ],
      );

      await client.query('COMMIT');

      return res.status(401).json({
        success: false,
        message: 'Username or password is incorrect.',
        remainingAttempts:
            3 - newFailedAttempts,
      });
    }

    // Password was correct.
    // Reset failed-login information.
    await client.query(
      `
      UPDATE users
      SET
        failed_attempts = 0,
        locked_until = NULL,
        updated_at = NOW()
      WHERE id = $1
      `,
      [user.id],
    );

    const accessToken =
        createAccessToken(user);

    const refreshToken =
        createRefreshToken();

    const refreshTokenHash =
        hashRefreshToken(refreshToken);

    const refreshDays =
        Number(
          process.env.REFRESH_TOKEN_DAYS || 7,
        );

    const refreshExpiresAt =
        new Date(
          Date.now() +
          refreshDays *
          24 *
          60 *
          60 *
          1000,
        );

    // Only the HASH of the refresh token
    // is stored in PostgreSQL.
    await client.query(
      `
      INSERT INTO auth_sessions (
        user_id,
        refresh_token_hash,
        expires_at
      )
      VALUES (
        $1,
        $2,
        $3
      )
      `,
      [
        user.id,
        refreshTokenHash,
        refreshExpiresAt,
      ],
    );

    await client.query('COMMIT');

    return res.status(200).json({
      success: true,

      user: {
        id: user.id,
        fullName: user.full_name,
        username: user.username,
        role: user.role,
        branchId: user.branch_id,
        mustChangePassword:
            user.must_change_password,
      },

      accessToken,
      refreshToken,
    });

  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    console.error('Login error:', error);

    return res.status(500).json({
      success: false,
      message: 'Internal server error.',
    });

  } finally {
    client.release();
  }
}

module.exports = {
  login,
};
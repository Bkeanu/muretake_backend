const crypto = require('crypto');
const jwt = require('jsonwebtoken');

function createAccessToken(user) {
  if (!process.env.JWT_ACCESS_SECRET) {
    throw new Error('JWT_ACCESS_SECRET is missing');
  }

  return jwt.sign(
    {
      role: user.role,
      branchId: user.branch_id,
    },
    process.env.JWT_ACCESS_SECRET,
    {
      subject: String(user.id),
      expiresIn: process.env.ACCESS_TOKEN_TTL || '15m',
      issuer: 'muretake-api',
      audience: 'muretake-app',
    },
  );
}

function createRefreshToken() {
  return crypto.randomBytes(64).toString('base64url');
}

function hashRefreshToken(refreshToken) {
  return crypto
    .createHash('sha256')
    .update(refreshToken)
    .digest('hex');
}

module.exports = {
  createAccessToken,
  createRefreshToken,
  hashRefreshToken,
};